package com.techdev.e_commercemobileapplication.SellerHome;

import static android.app.Activity.RESULT_OK;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.Image;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.techdev.e_commercemobileapplication.CommonMethod;
import com.techdev.e_commercemobileapplication.R;
import com.techdev.e_commercemobileapplication.RetrofitData.SellerAddItem;
import com.techdev.e_commercemobileapplication.SignUp.SignUpActivity;
import com.techdev.e_commercemobileapplication.Utils.ApiClient;
import com.techdev.e_commercemobileapplication.Utils.ApiInterface;
import com.techdev.e_commercemobileapplication.Utils.ConnectionDetector;
import com.techdev.e_commercemobileapplication.Utils.SharedPreferencesData;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.Blob;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class AddItemFragment extends Fragment {

    ImageView productImage;
    EditText productName, productPrice, productDescription;
    Button addItem, reset;

    SharedPreferences sp;
    ApiInterface apiInterface;

    ProgressDialog pd;

    // Uri indicates, where the image will be picked from
    private Uri filePath;

    // request code
    private final int PICK_IMAGE_REQUEST = 22;

    String sproductName, sproductPrice, sproductDescription;

    Bitmap bitmap;
    String img;

    public AddItemFragment() {
        // Required empty public constructor
    }


    @SuppressLint("WrongThread")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_add_item, container, false);

        apiInterface = ApiClient.getClient().create(ApiInterface.class);
        sp = getActivity().getSharedPreferences(SharedPreferencesData.PREF, Context.MODE_PRIVATE);


        productImage = view.findViewById(R.id.frag_add_item_ProductImage);
        productName = view.findViewById(R.id.frag_add_item_ProductName_input);
        productPrice = view.findViewById(R.id.frag_add_item_ProductPrice_input);
        productDescription = view.findViewById(R.id.frag_add_item_ProductDescription_input);

        addItem = view.findViewById(R.id.frag_add_item_addItemButton);
        reset = view.findViewById(R.id.frag_add_item_resetButton);

        productImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showFileChooser();
            }
        });


        addItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                img = getStringImage(bitmap);
                sproductName = productName.getText().toString();
                sproductPrice = productPrice.getText().toString();
                sproductDescription = productDescription.getText().toString();

                if(sproductName.isEmpty() || sproductName.equalsIgnoreCase("")){
                    productName.setError("Product Name is required");
                } else if(sproductPrice.isEmpty() || sproductPrice.equalsIgnoreCase("")){
                    productPrice.setError("Product Price is required");
                } else if(sproductDescription.isEmpty() || sproductDescription.equalsIgnoreCase("")){
                    productDescription.setError("Product Description is required");
                } else {
                    if(new ConnectionDetector(getActivity()).isConnectingToInternet()){
                        pd = new ProgressDialog(getActivity());
                        pd.setMessage("Please Wait...");
                        pd.setCancelable(false);
                        pd.show();
                        retrofitAddData();
                    }
                    else{
                        new ConnectionDetector(getActivity()).connectiondetect();
                    }

                }

            }
        });


        return view;
    }

    private void showFileChooser() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {

            filePath = data.getData();
            try {
                bitmap = MediaStore.Images.Media.getBitmap(getActivity().getContentResolver(), filePath);
                productImage.setImageBitmap(bitmap);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public String getStringImage(Bitmap bmp){
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.JPEG, 100, baos);
        byte[] imageBytes = baos.toByteArray();
        String encodedImage = Base64.encodeToString(imageBytes, Base64.DEFAULT);
        return encodedImage;
    }


    private void retrofitAddData() {
        String userID, sEmail;
        userID = sp.getString(SharedPreferencesData.ID,"");
        sEmail = sp.getString(SharedPreferencesData.EMAIL,"");

        retrofit2.Call<SellerAddItem> call = apiInterface.sellerAddItem(
                userID, sEmail, img, sproductName, sproductPrice, sproductDescription
        );

        call.enqueue(new Callback<SellerAddItem>() {
            @Override
            public void onResponse(Call<SellerAddItem> call, Response<SellerAddItem> response) {
                pd.dismiss();
                if(response.code()==200){
                    if(response.body().status==true){
                        new CommonMethod(getActivity(), response.body().message);
                        new CommonMethod(getActivity(), "Add SuccessFully");

                        productImage.setImageBitmap(null);
                        productName.setText("");
                        productPrice.setText("");
                        productDescription.setText("");

                    }
                    else{
                        new CommonMethod(getActivity(), response.body().message);
                    }
                }
                else{
                    new CommonMethod(getActivity(), "Server Error Code : "+response.code());
                }

            }

            @Override
            public void onFailure(Call<SellerAddItem> call, Throwable t) {
                pd.dismiss();
                new CommonMethod(getActivity(), t.getMessage());
            }
        });


    }

    public byte[] getBytes(InputStream inputStream) throws IOException {
        ByteArrayOutputStream byteBuffer = new ByteArrayOutputStream();
        int bufferSize = 1024;
        byte[] buffer = new byte[bufferSize];

        int len = 0;
        while ((len = inputStream.read(buffer)) != -1) {
            byteBuffer.write(buffer, 0, len);
        }
        return byteBuffer.toByteArray();
    }


}