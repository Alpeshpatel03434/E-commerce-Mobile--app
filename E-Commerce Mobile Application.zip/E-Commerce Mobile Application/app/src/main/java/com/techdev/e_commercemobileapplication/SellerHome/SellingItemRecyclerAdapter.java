package com.techdev.e_commercemobileapplication.SellerHome;

import static android.content.Context.MODE_PRIVATE;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.techdev.e_commercemobileapplication.AdminHome.AdminviewUserProfileActivity;
import com.techdev.e_commercemobileapplication.AdminHome.UserRecyclerAdapter;
import com.techdev.e_commercemobileapplication.AdminHome.UsersData;
import com.techdev.e_commercemobileapplication.CommonMethod;
import com.techdev.e_commercemobileapplication.R;
import com.techdev.e_commercemobileapplication.RetrofitData.DeleteSellerItem;
import com.techdev.e_commercemobileapplication.RetrofitData.UpdateSellerItem;
import com.techdev.e_commercemobileapplication.Utils.ApiClient;
import com.techdev.e_commercemobileapplication.Utils.ApiInterface;
import com.techdev.e_commercemobileapplication.Utils.ConnectionDetector;
import com.techdev.e_commercemobileapplication.Utils.SharedPreferencesData;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SellingItemRecyclerAdapter extends RecyclerView.Adapter<SellingItemRecyclerAdapter.MyHolder>  {

    Context context;
    ArrayList<ItemData> arrayList;
    Bundle bundle;

    ArrayList<ItemData> searchArrayList;
    ApiInterface apiInterface;
    ProgressDialog pd;
    SharedPreferences sp;

    Bitmap bitmapImage;

    public SellingItemRecyclerAdapter(Context context, ArrayList<ItemData> arrayList) {
        this.context = context;
        this.arrayList = arrayList;

        searchArrayList = new ArrayList<>();
        searchArrayList.addAll(arrayList);
    }


    @NonNull
    @Override
    public SellingItemRecyclerAdapter.MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.custom_sellingitem_recycler, parent, false);

        return new MyHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SellingItemRecyclerAdapter.MyHolder holder, @SuppressLint("RecyclerView") int position) {

        String img = arrayList.get(position).getProductImage();
        bitmapImage  = getBitmapImage(img);
        holder.ProductImage.setImageBitmap(bitmapImage);
        holder.ProductName.setText(arrayList.get(position).getProductName());
        holder.ProductPrice.setText(arrayList.get(position).getProductPrice());
        holder.ProductDescription.setText(arrayList.get(position).getProductDescription());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                bundle = new Bundle();

                bundle.putString("ProductID", arrayList.get(position).getProductID());
                bundle.putString("ProductImage", arrayList.get(position).getProductImage());
                bundle.putString("ProductName", arrayList.get(position).getProductName());
                bundle.putString("ProductPrice", arrayList.get(position).getProductPrice());
                bundle.putString("ProductDescription", arrayList.get(position).getProductDescription());
                Intent intent = new Intent(holder.itemView.getContext(), ItemViewActivity.class);
                intent.putExtras(bundle);
                context.startActivity(intent);

            }
        });

        holder.editable.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                holder.ProductName.setEnabled(true);
                holder.ProductPrice.setEnabled(true);
                holder.ProductDescription.setEnabled(true);

                holder.editable.setVisibility(View.GONE);
                holder.update.setVisibility(View.VISIBLE);
            }
        });

        holder.update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                holder.sProductName = holder.ProductName.getText().toString();
                holder.sProductPrice = holder.ProductPrice.getText().toString();
                holder.sProductDescription = holder.ProductDescription.getText().toString();

                if(holder.sProductName.isEmpty() || holder.sProductName.equalsIgnoreCase("")){
                    holder.ProductName.setError("Product Name is required");
                } else if(holder.sProductPrice.isEmpty() || holder.sProductPrice.equalsIgnoreCase("")){
                    holder.ProductPrice.setError("Product Price is required");
                } else if(holder.sProductDescription.isEmpty() || holder.sProductDescription.equalsIgnoreCase("")){
                    holder.ProductDescription.setError("Product Description is required");
                } else {
                    if(new ConnectionDetector(context.getApplicationContext()).isConnectingToInternet()){

                        String pid = arrayList.get(position).getProductID();
                        String userid = sp.getString(SharedPreferencesData.ID,"");
                        String email = sp.getString(SharedPreferencesData.EMAIL,"");

                        pd = new ProgressDialog(view.getContext());
                        pd.setMessage("Please Wait...");
                        pd.setCancelable(false);
                        pd.show();
                        retrofitUpdate(holder.itemView.getContext(), pid, userid, email, arrayList.get(position).getProductImage(), holder.sProductName, holder.sProductPrice, holder.sProductDescription);
                    }
                    else{
                        new ConnectionDetector(view.getContext()).connectiondetect();
                    }

                }

            }
        });

        holder.delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String record = arrayList.get(position).getProductID();
                pd = new ProgressDialog(holder.itemView.getContext());
                pd.setMessage("Please Wait...");
                pd.setCancelable(false);
                pd.show();
                retrofitDeleteProfile(holder.itemView.getContext(), record);
            }
        });

    }

    private void retrofitDeleteProfile(Context context, String record) {

        Call<DeleteSellerItem> call = apiInterface.deleteSellerItem(
                record
        );

        call.enqueue(new Callback<DeleteSellerItem>() {
            @Override
            public void onResponse(Call<DeleteSellerItem> call, Response<DeleteSellerItem> response) {

                pd.dismiss();
                if(response.code()==200){

                    if (response.body().status==true){

                        arrayList.remove(record);
                        searchArrayList.addAll(arrayList);
                        new CommonMethod(context, "Delete SuccessFull");
                        notifyDataSetChanged();


                    } else {
                        new CommonMethod(context, response.body().message);
                    }

                } else {
                    new CommonMethod(context,"Server Error Code : "+response.code());
                }

            }

            @Override
            public void onFailure(Call<DeleteSellerItem> call, Throwable t) {
                pd.dismiss();
                new CommonMethod(context, t.getMessage());
            }
        });

    }

    private void retrofitUpdate(Context context, String pid, String userid, String email, String image, String name, String price, String desc) {

        Call<UpdateSellerItem> call = apiInterface.updateSellerItem(
                pid, userid, email, image, name, price, desc
        );

        call.enqueue(new Callback<UpdateSellerItem>() {
            @Override
            public void onResponse(Call<UpdateSellerItem> call, Response<UpdateSellerItem> response) {

                pd.dismiss();
                if(response.code()==200){

                    if (response.body().status==true){

                        ItemData list = new ItemData();
                        list.setProductID(pid);
                        list.setProductImage(image);
                        list.setProductName(name);
                        list.setProductPrice(price);
                        list.setProductDescription(desc);
                        arrayList.set(arrayList.indexOf(pid), list);
                        //searchArrayList.set(arrayList.indexOf(sUserID), list);
                        searchArrayList.addAll(arrayList);
                        new CommonMethod(context, "Updated SuccessFully");
                        notifyDataSetChanged();

                    } else {
                        new CommonMethod(context, response.body().message);
                    }

                } else {
                    new CommonMethod(context,"Server Error Code : "+response.code());
                }

            }

            @Override
            public void onFailure(Call<UpdateSellerItem> call, Throwable t) {
                pd.dismiss();
                new CommonMethod(context, t.getMessage());
            }
        });

    }

    public Bitmap getBitmapImage(String bmp) {
        byte[] decodedString = Base64.decode(bmp, Base64.DEFAULT);
        Bitmap bitmap = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
        return bitmap;
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    protected class MyHolder extends RecyclerView.ViewHolder {

        ImageView ProductImage;
        EditText ProductName, ProductPrice, ProductDescription;
        Button update, delete, editable;

        String sProductName, sProductPrice, sProductDescription;

        public MyHolder(@NonNull View itemView) {
            super(itemView);

            apiInterface = ApiClient.getClient().create(ApiInterface.class);
            sp = context.getSharedPreferences(SharedPreferencesData.PREF, MODE_PRIVATE);

            ProductImage = itemView.findViewById(R.id.custom_sellingitem_recycler_ProductImage);
            ProductName = itemView.findViewById(R.id.custom_sellingitem_recycler_ProductName);
            ProductPrice = itemView.findViewById(R.id.custom_sellingitem_recycler_ProductPrice);
            ProductDescription = itemView.findViewById(R.id.custom_sellingitem_recycler_ProductDescription);

            editable = itemView.findViewById(R.id.custom_sellingitem_recycler_EditProfileButton);
            update = itemView.findViewById(R.id.custom_sellingitem_recycler_UpdateButton);
            delete = itemView.findViewById(R.id.custom_sellingitem_recycler_DeleteButton);

            ProductName.setEnabled(false);
            ProductPrice.setEnabled(false);
            ProductDescription.setEnabled(false);

            editable.setVisibility(View.VISIBLE);
            update.setVisibility(View.GONE);


        }
    }

    public void filter(String s) {
        s = s.toLowerCase(Locale.getDefault());
        arrayList.clear();
        if(s.equals("")){
            arrayList.addAll(searchArrayList);
        }
        else{
            for (ItemData list : searchArrayList){
                if(list.getProductName().contains(s) || list.getProductDescription().toLowerCase().contains(s) || list.getProductPrice().toLowerCase().contains(s)){
                    arrayList.add(list);
                }
            }
        }
        notifyDataSetChanged();
    }


}
