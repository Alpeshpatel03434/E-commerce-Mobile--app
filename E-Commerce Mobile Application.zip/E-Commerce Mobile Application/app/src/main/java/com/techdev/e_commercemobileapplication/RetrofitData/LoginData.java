package com.techdev.e_commercemobileapplication.RetrofitData;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;


public class LoginData {

    @SerializedName("Status")
    @Expose
    public Boolean status;
    @SerializedName("Message")
    @Expose
    public String message;
    @SerializedName("id")
    @Expose
    public String id;
    @SerializedName("firstname")
    @Expose
    public String firstname;
    @SerializedName("lastname")
    @Expose
    public String lastname;
    @SerializedName("gender")
    @Expose
    public String gender;
    @SerializedName("contact")
    @Expose
    public String contact;
    @SerializedName("email")
    @Expose
    public String email;
    @SerializedName("password")
    @Expose
    public String password;
    @SerializedName("type_of_account")
    @Expose
    public String typeOfAccount;
    @SerializedName("homeAddress")
    @Expose
    public String homeAddress;
    @SerializedName("city")
    @Expose
    public String city;
    @SerializedName("pincode")
    @Expose
    public String pincode;

}

