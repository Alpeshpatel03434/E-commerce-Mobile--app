package com.techdev.e_commercemobileapplication.AdminHome;

import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.SearchView;

import com.techdev.e_commercemobileapplication.CommonMethod;
import com.techdev.e_commercemobileapplication.R;
import com.techdev.e_commercemobileapplication.Utils.ApiClient;
import com.techdev.e_commercemobileapplication.Utils.MakeServiceCall;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;


public class UsersFragment extends Fragment {

    RecyclerView recyclerView;
    ArrayList<UsersData> arrayList;

    ProgressDialog pd;
    SharedPreferences sp;

    EditText searchView;

    public UsersFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_users, container, false);

        recyclerView = view.findViewById(R.id.frag_users_Dashboard_recyclerview);

        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        recyclerView.setItemAnimator(new DefaultItemAnimator());

        searchView = view.findViewById(R.id.frag_users_Dashboard_searchView);
        new setdata().execute();


        return view;
    }

    private class setdata extends AsyncTask<String, String, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(getActivity());
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @Override
        protected String doInBackground(String... strings) {
            HashMap<String,String> hashMap = new HashMap<>();

            hashMap.put("type_of_account", "Customer");

            return new MakeServiceCall().MakeServiceCall(ApiClient.BASE_URL+"admin_AllCustomerANDSeller.php", MakeServiceCall.POST, hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try {
                JSONObject jsonObject = new JSONObject(s);

                if(jsonObject.getBoolean("Status")==true){
                    new CommonMethod(getActivity(), jsonObject.getString("Message"));
                    JSONArray jsonArray = jsonObject.getJSONArray("response");
                    arrayList = new ArrayList<>();
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject object = jsonArray.getJSONObject(i);
                        UsersData list = new UsersData();
                        list.setID(object.getString("id"));
                        list.setFirstName(object.getString("firstname"));
                        list.setLastName(object.getString("lastname"));
                        list.setGender(object.getString("gender"));
                        list.setContact(object.getString("contact"));
                        list.setEmail(object.getString("email"));
                        list.setPassword(object.getString("password"));
                        list.setHomeAddress(object.getString("homeAddress"));
                        list.setCity(object.getString("city"));
                        list.setPincode(object.getString("pincode"));
                        arrayList.add(list);
                    }

                    UserRecyclerAdapter adapter = new UserRecyclerAdapter(getActivity(), arrayList);
                    recyclerView.setAdapter(adapter);

                    searchView.addTextChangedListener(new TextWatcher() {
                        @Override
                        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                        }

                        @Override
                        public void onTextChanged(CharSequence s, int start, int before, int count) {
                            if (s.toString().trim().equals("")) {
                                adapter.filter("");
                            } else {
                                adapter.filter(s.toString());
                            }
                        }

                        @Override
                        public void afterTextChanged(Editable s) {

                        }
                    });



                }
                else{
                    new CommonMethod(getActivity(), jsonObject.getString("Message"));
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }


}