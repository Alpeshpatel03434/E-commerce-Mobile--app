package com.techdev.e_commercemobileapplication.AdminHome;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import com.techdev.e_commercemobileapplication.CommonMethod;
import com.techdev.e_commercemobileapplication.R;
import com.techdev.e_commercemobileapplication.RetrofitData.AllUsers;
import com.techdev.e_commercemobileapplication.Utils.ApiClient;
import com.techdev.e_commercemobileapplication.Utils.ApiInterface;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class AdminAppStatusFragment extends Fragment {

    TextView numOfAllUsers, numOfAllCustomers, numOfAllShopper;
    ApiInterface apiInterface;
    ProgressDialog pd;

    public AdminAppStatusFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_admin_app_status, container, false);

        apiInterface = ApiClient.getClient().create(ApiInterface.class);

        numOfAllUsers = view.findViewById(R.id.admin_app_status_activeUsers_input);
        numOfAllCustomers = view.findViewById(R.id.admin_app_status_customer_input);
        numOfAllShopper = view.findViewById(R.id.admin_app_status_shop_input);

        pd = new ProgressDialog(getActivity());
        pd.setMessage("Please Wait...");
        pd.setCancelable(false);
        pd.show();
       // pd.dismiss();
        setTextStatus();
       // retrofitLoginData("alpeshpatel03434@gmail.com", "Alpesh1234@@");

        return view;
    }



    private void setTextStatus() {

        Call<AllUsers> call = apiInterface.AllUsers("1");

        call.enqueue(new Callback<AllUsers>() {
            @Override
            public void onResponse(Call<AllUsers> call, Response<AllUsers> response) {
                pd.dismiss();
                if(response.code()==200){
                    new CommonMethod(getActivity(), response.body().message);
                    if(response.body().status==true){
                        String numUsers = response.body().allNumberOFRow+"+";
                        String numCustomers = response.body().customerNumberOFRow+"+";
                        String numShoppers = response.body().shopperNumberOFRow+"+";

                        numOfAllUsers.setText(numUsers);
                        numOfAllCustomers.setText(numCustomers);
                        numOfAllShopper.setText(numShoppers);

                    } else {
                        new CommonMethod(getActivity(), response.body().message);
                    }

                } else {
                    new CommonMethod(getActivity(),"Server Error Code : "+response.code());
                }

            }

            @Override
            public void onFailure(Call<AllUsers> call, Throwable t) {
                new CommonMethod(getActivity(), t.getMessage());
            }
        });

    }
}