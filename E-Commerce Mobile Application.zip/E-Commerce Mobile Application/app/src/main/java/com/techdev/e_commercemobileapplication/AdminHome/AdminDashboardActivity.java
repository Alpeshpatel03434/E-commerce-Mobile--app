package com.techdev.e_commercemobileapplication.AdminHome;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.view.View;

import com.google.android.material.tabs.TabLayout;
import com.techdev.e_commercemobileapplication.CommonMethod;
import com.techdev.e_commercemobileapplication.R;
import com.techdev.e_commercemobileapplication.RetrofitData.AllUsers;
import com.techdev.e_commercemobileapplication.Utils.ApiClient;
import com.techdev.e_commercemobileapplication.Utils.ApiInterface;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AdminDashboardActivity extends AppCompatActivity {

    TabLayout tabLayout;
    ViewPager viewPager;

    ApiInterface apiInterface;
    ProgressDialog pd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_dashboard);
        getSupportActionBar().hide();

        apiInterface = ApiClient.getClient().create(ApiInterface.class);

        tabLayout = findViewById(R.id.admin_dashboard_tablayout);
        viewPager = findViewById(R.id.admin_dashboard_viewPager);

        tabLayout.post(new Runnable() {
            @Override
            public void run() {
                tabLayout.setupWithViewPager(viewPager);
            }
        });

       // setTextStatus();
        viewPager.setAdapter(new DashboardTabActivityAdapter(getSupportFragmentManager()));
    }

    private class DashboardTabActivityAdapter extends FragmentPagerAdapter {

        public DashboardTabActivityAdapter(FragmentManager supportFragmentManager) {
            super(supportFragmentManager);
        }

        @Nullable
        @Override
        public CharSequence getPageTitle(int position) {

            switch (position){
                case 0 :
                    return "App Status";
                case 1 :
                    return "Users";
                case 2 :
                    return "Seller";
            }

            return super.getPageTitle(position);
        }

        @NonNull
        @Override
        public Fragment getItem(int position) {
            switch (position){
                case 0 :
                    return new AdminAppStatusFragment();
                case 1 :
                    return new UsersFragment();
                case 2 :
                    return new ShopperFragment();
            }
            return null;
        }

        @Override
        public int getCount() {
            return 3;
        }

    }

    private void setTextStatus() {

        Call<AllUsers> call = apiInterface.AllUsers("1");

        call.enqueue(new Callback<AllUsers>() {
            @Override
            public void onResponse(Call<AllUsers> call, Response<AllUsers> response) {
              //  pd.dismiss();
                if(response.code()==200){
                    new CommonMethod(AdminDashboardActivity.this, response.body().message);
                    if(response.body().status==true){
                        String numUsers = String.valueOf(response.body().allNumberOFRow);
                       // String numCustomers = String.valueOf(response.body().customerNumberOFRow);
                        //String numShoppers = String.valueOf(response.body().shopperNumberOFRow);

                     //   new CommonMethod(AdminDashboardActivity.this, numUsers+" "+numCustomers+" "+numShoppers);

                    } else {
                        new CommonMethod(AdminDashboardActivity.this, response.body().message);
                    }

                } else {
                    new CommonMethod(AdminDashboardActivity.this,"Server Error Code : "+response.code());
                }

            }

            @Override
            public void onFailure(Call<AllUsers> call, Throwable t) {
                new CommonMethod(AdminDashboardActivity.this, t.getMessage());
            }
        });

    }
}