package com.techdev.e_commercemobileapplication.Utils;

public class DataBaseServerURL {

    // TODO Local IP Address
    public static final String URL = "http://192.168.43.46/android_demo/";

    //TODO Live URL
   // public static final String URL = "https://fleecy-defeats.000webhostapp.com/";

    public static final String PREF = "pref";
    public static final String ID = "id";
    public static final String NAME = "name";
    public static final String GENDER = "gender";
    public static final String CONTACT = "contact";
    public static final String EMAIL = "email";
    public static final String CITY = "city";

}
