package com.techdev.e_commercemobileapplication.RetrofitData;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class AllUsers {

    @SerializedName("Status")
    @Expose
    public Boolean status;
    @SerializedName("Message")
    @Expose
    public String message;
    @SerializedName("AllNumberOFRow")
    @Expose
    public Integer allNumberOFRow;
    @SerializedName("ShopperNumberOFRow")
    @Expose
    public Integer shopperNumberOFRow;
    @SerializedName("CustomerNumberOFRow")
    @Expose
    public Integer customerNumberOFRow;


//    @SerializedName("Status")
//    @Expose
//    public Boolean status;
//    @SerializedName("Message")
//    @Expose
//    public String message;
//    @SerializedName("AllNumberOFRow")
//    @Expose
//    public Integer allNumberOFRow;

//    @SerializedName("Status")
//    @Expose
//    public Boolean status;
//    @SerializedName("Message")
//    @Expose
//    public String message;
//    @SerializedName("AllNumberOFRow")
//    @Expose
//    public Integer allNumberOFRow;

}
