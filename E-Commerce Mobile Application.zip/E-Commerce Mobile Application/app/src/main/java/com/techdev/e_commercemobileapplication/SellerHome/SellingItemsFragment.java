package com.techdev.e_commercemobileapplication.SellerHome;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import com.techdev.e_commercemobileapplication.AdminHome.UserRecyclerAdapter;
import com.techdev.e_commercemobileapplication.AdminHome.UsersData;
import com.techdev.e_commercemobileapplication.CommonMethod;
import com.techdev.e_commercemobileapplication.R;
import com.techdev.e_commercemobileapplication.RetrofitData.getSellerItem;
import com.techdev.e_commercemobileapplication.RetrofitData.getSellerItemResponse;
import com.techdev.e_commercemobileapplication.Utils.ApiClient;
import com.techdev.e_commercemobileapplication.Utils.ApiInterface;
import com.techdev.e_commercemobileapplication.Utils.MakeServiceCall;
import com.techdev.e_commercemobileapplication.Utils.SharedPreferencesData;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class SellingItemsFragment extends Fragment {

    RecyclerView recyclerView;

    ApiInterface apiInterface;
    ProgressDialog pd;
    SharedPreferences sp;

    EditText searchView;
    String id, email;
    ArrayList<ItemData> arrayList;

    public SellingItemsFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_selling_items, container, false);

        apiInterface = ApiClient.getClient().create(ApiInterface.class);
        sp = getActivity().getSharedPreferences(SharedPreferencesData.PREF, Context.MODE_PRIVATE);


        recyclerView = view.findViewById(R.id.frag_selling_home_recyclerview);

        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        recyclerView.setItemAnimator(new DefaultItemAnimator());

        searchView = view.findViewById(R.id.frag_selling_home_searchView);
        id = sp.getString(SharedPreferencesData.ID,"");;
        email =  sp.getString(SharedPreferencesData.EMAIL,"");
        new setSellerItemData().execute();


        return view;
    }

    private class setSellerItemData extends AsyncTask<String, String, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(getActivity());
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @Override
        protected String doInBackground(String... strings) {
            HashMap<String,String> hashMap = new HashMap<>();

            hashMap.put("id", id);
            hashMap.put("email", email);

            return new MakeServiceCall().MakeServiceCall(ApiClient.BASE_URL+"getSellerItems.php", MakeServiceCall.POST, hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try {
                JSONObject jsonObject = new JSONObject(s);

                if(jsonObject.getBoolean("Status")==true){
                    new CommonMethod(getActivity(), jsonObject.getString("Message"));
                    JSONArray jsonArray = jsonObject.getJSONArray("response");
                    arrayList = new ArrayList<>();
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject object = jsonArray.getJSONObject(i);
                        ItemData list = new ItemData();
                        list.setProductID(object.getString("record"));
                        list.setProductImage(object.getString("p_image"));
                        list.setProductName(object.getString("p_name"));
                        list.setProductPrice(object.getString("p_price"));
                        list.setProductDescription(object.getString("p_description"));

                        arrayList.add(list);
                    }

                    SellingItemRecyclerAdapter adapter = new SellingItemRecyclerAdapter(getActivity(), arrayList);
                    recyclerView.setAdapter(adapter);

                    searchView.addTextChangedListener(new TextWatcher() {
                        @Override
                        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                        }

                        @Override
                        public void onTextChanged(CharSequence s, int start, int before, int count) {
                            if (s.toString().trim().equals("")) {
                                adapter.filter("");
                            } else {
                                adapter.filter(s.toString());
                            }
                        }

                        @Override
                        public void afterTextChanged(Editable s) {

                        }
                    });


                }
                else{
                    new CommonMethod(getActivity(), jsonObject.getString("Message"));
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

}