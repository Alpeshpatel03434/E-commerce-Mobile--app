package com.techdev.e_commercemobileapplication.RetrofitData;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class getSellerItemResponse {

    @SerializedName("id")
    @Expose
    public String id;
    @SerializedName("email")
    @Expose
    public String email;
    @SerializedName("p_image")
    @Expose
    public String pImage;
    @SerializedName("p_name")
    @Expose
    public String pName;
    @SerializedName("p_price")
    @Expose
    public String pPrice;
    @SerializedName("p_description")
    @Expose
    public String pDescription;

}
