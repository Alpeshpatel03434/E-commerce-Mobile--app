package com.techdev.e_commercemobileapplication.Admin;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.android.gms.common.SignInButton;
import com.techdev.e_commercemobileapplication.AdminCredential;
import com.techdev.e_commercemobileapplication.AdminHome.AdminDashboardActivity;
import com.techdev.e_commercemobileapplication.CommonMethod;
import com.techdev.e_commercemobileapplication.Login.LoginActivity;
import com.techdev.e_commercemobileapplication.R;
import com.techdev.e_commercemobileapplication.Utils.ConnectionDetector;

public class AdminLoginActivity extends AppCompatActivity {

    EditText email, password;
    TextView forgotPassword, customerORshopper;
    Button adminlogin;

    String EmailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
    private String Email, Password;

    ProgressDialog pd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_login);

        email = findViewById(R.id.Admin_login_email_input);
        password = findViewById(R.id.Admin_login_passwd_input);

        forgotPassword = findViewById(R.id.Admin_login_forgotPassword);
        forgotPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        adminlogin = findViewById(R.id.Admin_login_Admin_loginButton);
        adminlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Email = email.getText().toString();
                Password = password.getText().toString();

                if (Email.isEmpty() || Email.equals("")){
                    email.setError("Email is required");
                } else if (!Email.matches(EmailPattern) || Email.length()>10 && Email.length()<10){
                    email.setError("Please Enter valid Email/Mobile number");
                }  else if (Password.isEmpty() || Password.equals("")){
                    password.setError("Password is required");
                } else if (Password.length()<8){
                    password.setError("Password must be 8 char long");
                } else {
                    if(new ConnectionDetector(AdminLoginActivity.this).isConnectingToInternet()){
                        //new CommonMethod(JsonSignupActivity.this,"Internet/Wifi Connected");
                        //  new dologin().execute();

                        pd = new ProgressDialog(AdminLoginActivity.this);
                        pd.setMessage("Please Wait...");
                        pd.setCancelable(false);
                        pd.show();
                        AdminLoginMethod(Email, Password);

                    }
                    else{
                        new ConnectionDetector(AdminLoginActivity.this).connectiondetect();
                    }
                }
            }
        });

        customerORshopper = findViewById(R.id.Admin_login_customerORshopper);
        customerORshopper.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new CommonMethod(AdminLoginActivity.this, LoginActivity.class);
            }
        });

    }

    private void AdminLoginMethod(String Email, String Password) {
        AdminCredential obj = new AdminCredential();
        Boolean valid = obj.CheckCredential(Email, Password);
        pd.dismiss();
        if(valid){
            new CommonMethod(AdminLoginActivity.this, "SuccessFully Login");
            new CommonMethod(AdminLoginActivity.this, AdminDashboardActivity.class);
        } else {
            new CommonMethod(AdminLoginActivity.this, "UnSuccessFull");
            new CommonMethod(AdminLoginActivity.this, "Not Valid Credential");
        }
    }
}