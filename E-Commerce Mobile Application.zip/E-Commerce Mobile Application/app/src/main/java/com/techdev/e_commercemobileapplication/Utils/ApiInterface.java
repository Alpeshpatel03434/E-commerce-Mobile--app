package com.techdev.e_commercemobileapplication.Utils;

import com.techdev.e_commercemobileapplication.RetrofitData.AllUsers;
import com.techdev.e_commercemobileapplication.RetrofitData.DeleteProfile;
import com.techdev.e_commercemobileapplication.RetrofitData.DeleteSellerItem;
import com.techdev.e_commercemobileapplication.RetrofitData.LoginData;
import com.techdev.e_commercemobileapplication.RetrofitData.SellerAddItem;
import com.techdev.e_commercemobileapplication.RetrofitData.SignupData;
import com.techdev.e_commercemobileapplication.RetrofitData.UpdateProfile;
import com.techdev.e_commercemobileapplication.RetrofitData.UpdateSellerItem;
import com.techdev.e_commercemobileapplication.RetrofitData.getSellerItem;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface ApiInterface {

    @FormUrlEncoded
    @POST("NewUser.php")
    Call<SignupData> signupData(
            @Field("firstname") String FIRSTNAME,
            @Field("lastname") String LASTNAME,
            @Field("gender") String GENDER,
            @Field("contact") String CONTACT,
            @Field("email") String EMAIL,
            @Field("password") String PASSWORD,
            @Field("type_of_account") String TYPE_OF_ACCOUNT,
            @Field("homeAddress") String HOMEADDRESS,
            @Field("city") String CITY,
            @Field("pincode") String PINCODE
    );

    @FormUrlEncoded
    @POST("login.php")
    Call<LoginData> loginData(
            @Field("email") String EMAIL,
            @Field("password") String PASSWORD
    );


    @FormUrlEncoded
    @POST("admin_Allusers.php")
    Call<AllUsers> AllUsers(
            @Field("temp") String temp
    );

    @FormUrlEncoded
    @POST("deleteProfile.php")
    Call<DeleteProfile> deleteProfile(
            @Field("userId") String USERID
    );

    @FormUrlEncoded
    @POST("UpdateProfile.php")
    Call<UpdateProfile> updateProfile(
            @Field("userId") String USERID,
            @Field("firstname") String FIRSTNAME,
            @Field("lastname") String LASTNAME,
            @Field("gender") String GENDER,
            @Field("contact") String CONTACT,
            @Field("email") String EMAIL,
            @Field("password") String PASSWORD,
            @Field("homeAddress") String HOMEADDRESS,
            @Field("city") String CITY,
            @Field("pincode") String PINCODE
    );


    @FormUrlEncoded
    @POST("seller.php")
    Call<SellerAddItem> sellerAddItem(
            @Field("userID") String USERID,
            @Field("email") String Email,
            @Field("p_image") String PRODUCT_IMAGE,
            @Field("p_name") String PRODUCT_NAME,
            @Field("p_price") String PRODUCT_PRICE,
            @Field("p_description") String PRODUCT_DESCRIPTION
    );


    @FormUrlEncoded
    @POST("getSellerItems.php")
    Call<getSellerItem> getsellerItem(
            @Field("id") String ID,
            @Field("email") String Email
    );

    @FormUrlEncoded
    @POST("UpdateItem.php")
    Call<UpdateSellerItem> updateSellerItem(
            @Field("PID") String ProductID,
            @Field("userID") String USERID,
            @Field("email") String Email,
            @Field("p_image") String PRODUCT_IMAGE,
            @Field("p_name") String PRODUCT_NAME,
            @Field("p_price") String PRODUCT_PRICE,
            @Field("p_description") String PRODUCT_DESCRIPTION
    );

    @FormUrlEncoded
    @POST("deleteSellerItem.php")
    Call<DeleteSellerItem> deleteSellerItem(
            @Field("PID") String ProductID
    );



}