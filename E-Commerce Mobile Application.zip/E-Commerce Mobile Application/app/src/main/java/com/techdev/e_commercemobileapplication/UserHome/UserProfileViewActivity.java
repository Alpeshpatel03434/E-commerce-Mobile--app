package com.techdev.e_commercemobileapplication.UserHome;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.techdev.e_commercemobileapplication.CommonMethod;
import com.techdev.e_commercemobileapplication.Login.LoginActivity;
import com.techdev.e_commercemobileapplication.R;
import com.techdev.e_commercemobileapplication.RetrofitData.DeleteProfile;
import com.techdev.e_commercemobileapplication.RetrofitData.UpdateProfile;
import com.techdev.e_commercemobileapplication.Utils.ApiClient;
import com.techdev.e_commercemobileapplication.Utils.ApiInterface;
import com.techdev.e_commercemobileapplication.Utils.ConnectionDetector;
import com.techdev.e_commercemobileapplication.Utils.SharedPreferencesData;

import java.io.IOException;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class UserProfileViewActivity extends AppCompatActivity {

    ImageView userProfile;

    TextView FirstLastName, gender, FullAddress;
    EditText Contact, Email;

    Button update, editprofile, delete, back, logout;

    EditText FirstName, LastName, HomeAddress, City, Pincode;
    RadioGroup Gender;

    LinearLayout fANDlName_Linearlayout, fullAddress_Linearlayout;
    private String sUserID, sFirstName, sLastName, sGender, sEmail, sPassword, sContact, sHomeAddress, sCity, sPincode;

    String EmailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

    SharedPreferences sp;
    ApiInterface apiInterface;
    ProgressDialog pd;

    // Uri indicates, where the image will be picked from
    private Uri filePath;

    // request code
    private final int PICK_IMAGE_REQUEST = 22;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_profile_view);

        sp = getSharedPreferences(SharedPreferencesData.PREF, MODE_PRIVATE);
        apiInterface = ApiClient.getClient().create(ApiInterface.class);

        userProfile = findViewById(R.id.user_profile_userimage);

        FirstLastName = findViewById(R.id.user_profile_firstAndLastname);
        gender = findViewById(R.id.user_profile_gender);
        Contact = findViewById(R.id.user_profile_contact);
        Email = findViewById(R.id.user_profile_email);
        FullAddress = findViewById(R.id.user_profile_shopFullAddress);

        Contact.setEnabled(false);
        Email.setEnabled(false);

        fANDlName_Linearlayout = findViewById(R.id.user_profile_firstAndLastname_editable);
        FirstName = findViewById(R.id.user_profile_firstName);
        LastName = findViewById(R.id.user_profile_lastName);

        Gender = findViewById(R.id.user_profile_radioGroup_gender);

        fullAddress_Linearlayout = findViewById(R.id.user_profile_homeAddressANDcityANDpincode_editable);
        HomeAddress = findViewById(R.id.user_profile_homeAddress);
        City = findViewById(R.id.user_profile_city);
        Pincode = findViewById(R.id.user_profile_pincode);

        editprofile = findViewById(R.id.user_profile_EditButton);
        update = findViewById(R.id.user_profile_UpdateButton);
        delete = findViewById(R.id.user_profile_DeleteButton);

        editprofile.setVisibility(View.VISIBLE);
        update.setVisibility(View.GONE);
        fANDlName_Linearlayout.setVisibility(View.GONE);
        Gender.setVisibility(View.GONE);
        fullAddress_Linearlayout.setVisibility(View.GONE);



        FirstLastName.setText(sp.getString(SharedPreferencesData.FIRSTNAME, "")+" "+sp.getString(SharedPreferencesData.LASTNAME, ""));
        gender.setText(sp.getString(SharedPreferencesData.GENDER, ""));
        Contact.setText(sp.getString(SharedPreferencesData.CONTACT, ""));
        Email.setText(sp.getString(SharedPreferencesData.EMAIL, ""));
        FullAddress.setText(sp.getString(SharedPreferencesData.HOMEORSHOPADDRESS, "")+" "+sp.getString(SharedPreferencesData.CITY, "")+" "+sp.getString(SharedPreferencesData.PINCODE, ""));


        userProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SelectImage();
            }
        });

        Gender.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                RadioButton radioButton = findViewById(i);
                sGender = radioButton.getText().toString();
            }
        });

        back = findViewById(R.id.user_profile_BackButton);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });


        editprofile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirstLastName.setVisibility(View.GONE);
                gender.setVisibility(View.GONE);
                FullAddress.setVisibility(View.GONE);

                Contact.setEnabled(true);
                Email.setEnabled(true);

                editprofile.setVisibility(View.GONE);
                update.setVisibility(View.VISIBLE);
                fANDlName_Linearlayout.setVisibility(View.VISIBLE);
                Gender.setVisibility(View.VISIBLE);
                fullAddress_Linearlayout.setVisibility(View.VISIBLE);
            }
        });

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                sUserID = sp.getString(SharedPreferencesData.ID, "");
                sPassword = sp.getString(SharedPreferencesData.PASSWORD, "");

                sFirstName = FirstName.getText().toString();
                sLastName = LastName.getText().toString();
                sContact = Contact.getText().toString();
                sEmail = Email.getText().toString();
                sHomeAddress = HomeAddress.getText().toString();
                sCity = City.getText().toString();
                sPincode = Pincode.getText().toString();

                if (sFirstName.isEmpty() || sFirstName.equals("")){
                    FirstName.setError("FirstName is required");
                } else if (sLastName.isEmpty() || sLastName.equals("")){
                    LastName.setError("LastName is required");
                } else if (Gender.getCheckedRadioButtonId() == -1) {
                    new CommonMethod(UserProfileViewActivity.this, "Please Select Gender");
                } else if (sEmail.isEmpty() || sEmail.equals("")){
                    Email.setError("Email is required");
                } else if (!sEmail.matches(EmailPattern)){
                    Email.setError("Please Enter valid Email");
                }  else if (sContact.isEmpty() || sContact.equals("")){
                    Contact.setError("Contact number is required");
                } else if (sContact.length()<10 && sContact.length()>10){
                    Contact.setError("Please Enter valid Mobile number");
                } else if (sHomeAddress.isEmpty() || sHomeAddress.equals("")){
                    HomeAddress.setError("Home Address is required");
                } else if (sCity.isEmpty() || sCity.equals("-")){
                    City.setError("City is required");
                } else if (sPincode.isEmpty() || sPincode.equals("")){
                    Pincode.setError("Pincode is required");
                } else if (sPincode.length()<6 && sPincode.length()>6){
                    Pincode.setError("Please Enter valid Pincode");
                }
                else {
                    if(new ConnectionDetector(UserProfileViewActivity.this).isConnectingToInternet()){

                        pd = new ProgressDialog(UserProfileViewActivity.this);
                        pd.setMessage("Please Wait...");
                        pd.setCancelable(false);
                        pd.show();

                        retrofitUpdateData(sUserID, sFirstName, sLastName, sGender, sContact, sEmail, sPassword, sHomeAddress, sCity, sPincode);

                        Contact.setEnabled(false);
                        Email.setEnabled(false);

                        editprofile.setVisibility(View.VISIBLE);
                        update.setVisibility(View.GONE);
                        fANDlName_Linearlayout.setVisibility(View.GONE);
                        Gender.setVisibility(View.GONE);
                        fullAddress_Linearlayout.setVisibility(View.GONE);

                    }
                    else{
                        new ConnectionDetector(UserProfileViewActivity.this).connectiondetect();
                    }
                }

            }
        });

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String userID = sUserID;//arrayList.get(position).getID();
                pd = new ProgressDialog(UserProfileViewActivity.this);
                pd.setMessage("Please Wait...");
                pd.setCancelable(false);
                pd.show();
                retrofitDeleteProfile(userID);

            }
        });


        logout  = findViewById(R.id.user_profile_logoutButton);
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sp.edit().clear().commit();
                new CommonMethod(UserProfileViewActivity.this, LoginActivity.class);
            }
        });



    }


    private void retrofitUpdateData(String sUserID, String sFirstName, String sLastName, String sGender, String  sContact, String sEmail, String sPassword, String sHomeAddress, String sCity, String sPincode) {

        Call<UpdateProfile> call = apiInterface.updateProfile(
                sUserID, sFirstName, sLastName, sGender, sContact, sEmail, sPassword, sHomeAddress, sCity, sPincode
        );

        call.enqueue(new Callback<UpdateProfile>() {
            @Override
            public void onResponse(Call<UpdateProfile> call, Response<UpdateProfile> response) {
                pd.dismiss();
                if(response.code()==200){

                    if (response.body().status==true){

                        FirstLastName.setText(sFirstName+" "+sLastName);
                        gender.setText(sGender);
                        Contact.setText(sContact);
                        Email.setText(sEmail);
                        FullAddress.setText(sHomeAddress+" "+sCity+" "+sPincode);

                        new CommonMethod(UserProfileViewActivity.this, "Updated SuccessFully");


                    } else {
                        new CommonMethod(UserProfileViewActivity.this, response.body().message);
                    }

                } else {
                    new CommonMethod(UserProfileViewActivity.this,"Server Error Code : "+response.code());
                }

            }

            @Override
            public void onFailure(Call<UpdateProfile> call, Throwable t) {
                pd.dismiss();
                new CommonMethod(UserProfileViewActivity.this, t.getMessage());
            }
        });



    }

    private void retrofitDeleteProfile(String userID) {

        retrofit2.Call<DeleteProfile> call = apiInterface.deleteProfile(userID);

        call.enqueue(new Callback<DeleteProfile>() {
            @Override
            public void onResponse(Call<DeleteProfile> call, Response<DeleteProfile> response) {
                pd.dismiss();
                if(response.code()==200){

                    if (response.body().status==true){

                        new CommonMethod(UserProfileViewActivity.this, "Delete SuccessFull");
                        onBackPressed();

                    } else {
                        new CommonMethod(UserProfileViewActivity.this, response.body().message);
                    }

                } else {
                    new CommonMethod(UserProfileViewActivity.this,"Server Error Code : "+response.code());
                }

            }

            @Override
            public void onFailure(Call<DeleteProfile> call, Throwable t) {
                pd.dismiss();
                new CommonMethod(UserProfileViewActivity.this, t.getMessage());
            }
        });

    }

    // Select Image method
    private void SelectImage()
    {

        // Defining Implicit Intent to mobile gallery
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(
                Intent.createChooser(
                        intent,
                        "Select Image from here..."),
                PICK_IMAGE_REQUEST);
    }

    // Override onActivityResult method
    @Override
    protected void onActivityResult(int requestCode,
                                    int resultCode,
                                    Intent data)
    {

        super.onActivityResult(requestCode,
                resultCode,
                data);

        // checking request code and result code
        // if request code is PICK_IMAGE_REQUEST and
        // resultCode is RESULT_OK
        // then set image in the image view
        if (requestCode == PICK_IMAGE_REQUEST
                && resultCode == RESULT_OK
                && data != null
                && data.getData() != null) {

            // Get the Uri of data
            filePath = data.getData();
            try {

                // Setting image on image view using Bitmap
                Bitmap bitmap = MediaStore
                        .Images
                        .Media
                        .getBitmap(
                                getContentResolver(),
                                filePath);
                userProfile.setImageBitmap(bitmap);
            }

            catch (IOException e) {
                // Log the exception
                e.printStackTrace();
            }
        }
    }


}