package com.techdev.e_commercemobileapplication.Login;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.android.gms.common.SignInButton;
import com.techdev.e_commercemobileapplication.Admin.AdminLoginActivity;
import com.techdev.e_commercemobileapplication.CommonMethod;
import com.techdev.e_commercemobileapplication.SellerHome.ShopperDashboardActivity;
import com.techdev.e_commercemobileapplication.R;
import com.techdev.e_commercemobileapplication.RetrofitData.LoginData;
import com.techdev.e_commercemobileapplication.SignUp.SignUpActivity;
import com.techdev.e_commercemobileapplication.UserHome.UserDashboardActivity;
import com.techdev.e_commercemobileapplication.Utils.ApiClient;
import com.techdev.e_commercemobileapplication.Utils.ApiInterface;
import com.techdev.e_commercemobileapplication.Utils.ConnectionDetector;
import com.techdev.e_commercemobileapplication.Utils.SharedPreferencesData;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {

    EditText email, password;
    TextView forgotPassword, signup, adminLogin;
    Button login;
    SignInButton googleSignUp;

    String EmailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
    private String Email, Password;

    ApiInterface apiInterface;
    ProgressDialog pd;

    SharedPreferences sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        getSupportActionBar().setTitle("Login/Signup");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        apiInterface = ApiClient.getClient().create(ApiInterface.class);
        sp = getSharedPreferences(SharedPreferencesData.PREF, MODE_PRIVATE);


        email = findViewById(R.id.login_email_input);
        password = findViewById(R.id.login_passwd_input);

        forgotPassword = findViewById(R.id.login_forgotPassword);
        forgotPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        login = findViewById(R.id.login_loginButton);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Email = email.getText().toString();
                Password = password.getText().toString();

                if (Email.isEmpty() || Email.equals("")){
                    email.setError("Email is required");
                } else if (!Email.matches(EmailPattern) || Email.length()>10 && Email.length()<10){
                    email.setError("Please Enter valid Email/Mobile number");
                }  else if (Password.isEmpty() || Password.equals("")){
                    password.setError("Password is required");
                } else if (Password.length()<8){
                    password.setError("Password must be 8 char long");
                } else {
                    if(new ConnectionDetector(LoginActivity.this).isConnectingToInternet()){
                        //new CommonMethod(JsonSignupActivity.this,"Internet/Wifi Connected");
                      //  new dologin().execute();

                        pd = new ProgressDialog(LoginActivity.this);
                        pd.setMessage("Please Wait...");
                        pd.setCancelable(false);
                        pd.show();
                        retrofitLoginData();

                    }
                    else{
                        new ConnectionDetector(LoginActivity.this).connectiondetect();
                    }
                }



            }
        });

        signup = findViewById(R.id.login_signupButton);
        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(LoginActivity.this, SignUpActivity.class));
                //new CommonMethod(LoginActivity.this, SignUpActivity.class);
            }
        });

        googleSignUp = findViewById(R.id.login_googleSignIn);
        googleSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });


        adminLogin = findViewById(R.id.login_AdminButton);
        adminLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new CommonMethod(LoginActivity.this, AdminLoginActivity.class);
            }
        });



    }


    private void retrofitLoginData() {

        Call<LoginData> call = apiInterface.loginData(
          Email, Password
        );

        call.enqueue(new Callback<LoginData>() {
            @Override
            public void onResponse(Call<LoginData> call, Response<LoginData> response) {
                pd.dismiss();
                if(response.code()==200){
                    if(response.body().status==true){
                        new CommonMethod(LoginActivity.this, response.body().message);

                        if(response.body().typeOfAccount.equalsIgnoreCase("Customer")) {

                            sp.edit().putString(SharedPreferencesData.ID, response.body().id).commit();
                            sp.edit().putString(SharedPreferencesData.FIRSTNAME, response.body().firstname).commit();
                            sp.edit().putString(SharedPreferencesData.LASTNAME, response.body().lastname).commit();
                            sp.edit().putString(SharedPreferencesData.GENDER, response.body().gender).commit();
                            sp.edit().putString(SharedPreferencesData.CONTACT, response.body().contact).commit();
                            sp.edit().putString(SharedPreferencesData.EMAIL, response.body().email).commit();
                            sp.edit().putString(SharedPreferencesData.PASSWORD, response.body().password).commit();
                            sp.edit().putString(SharedPreferencesData.TYPEOFACCOUNT, "Customer").commit();
                            sp.edit().putString(SharedPreferencesData.HOMEORSHOPADDRESS, response.body().homeAddress).commit();
                            sp.edit().putString(SharedPreferencesData.CITY, response.body().city).commit();
                            sp.edit().putString(SharedPreferencesData.PINCODE, response.body().pincode).commit();

                            new CommonMethod(LoginActivity.this, UserDashboardActivity.class);
                        } else if(response.body().typeOfAccount.equalsIgnoreCase("Seller")) {

                            sp.edit().putString(SharedPreferencesData.ID, response.body().id).commit();
                            sp.edit().putString(SharedPreferencesData.FIRSTNAME, response.body().firstname).commit();
                            sp.edit().putString(SharedPreferencesData.LASTNAME, response.body().lastname).commit();
                            sp.edit().putString(SharedPreferencesData.GENDER, response.body().gender).commit();
                            sp.edit().putString(SharedPreferencesData.CONTACT, response.body().contact).commit();
                            sp.edit().putString(SharedPreferencesData.EMAIL, response.body().email).commit();
                            sp.edit().putString(SharedPreferencesData.PASSWORD, response.body().password).commit();
                            sp.edit().putString(SharedPreferencesData.TYPEOFACCOUNT, "Seller").commit();
                            sp.edit().putString(SharedPreferencesData.HOMEORSHOPADDRESS, response.body().homeAddress).commit();
                            sp.edit().putString(SharedPreferencesData.CITY, response.body().city).commit();
                            sp.edit().putString(SharedPreferencesData.PINCODE, response.body().pincode).commit();

                            new CommonMethod(LoginActivity.this, ShopperDashboardActivity.class);
                        } else {
                            new CommonMethod(LoginActivity.this, "Try Again...");
                        }
                    }
                    else{
                        new CommonMethod(LoginActivity.this, response.body().message);
                    }
                }
                else{
                    new CommonMethod(LoginActivity.this,"Server Error Code : "+response.code());
                }
            }

            @Override
            public void onFailure(Call<LoginData> call, Throwable t) {
                pd.dismiss();
                new CommonMethod(LoginActivity.this, t.getMessage());
            }
        });

    }


    @Override
    public void onBackPressed() {
        //super.onBackPressed();
        finishAffinity();
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }


}