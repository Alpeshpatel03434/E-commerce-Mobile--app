package com.techdev.e_commercemobileapplication.Utils;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ApiClient {

    // TODO Local IP Address
    public static final String BASE_URL = "http://192.168.43.46/ecmapp/";

    //TODO Live URL
    // public static final String BASE_URL = "https://fleecy-defeats.000webhostapp.com/";

    private static Retrofit retrofit = null;

    public static Retrofit getClient() {
        if (retrofit == null) {
            retrofit = new Retrofit.Builder()
                    .baseUrl(BASE_URL)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
        }
        return retrofit;
    }
  //  private static ApiClient apiClient;

//    private ApiClient(){
//        apiClient = new Retrofit.Builder()
//                .baseUrl(BASE_URL)
//                .addConverterFactory(GsonConverterFactory.create())
//                .build();
//    }

}