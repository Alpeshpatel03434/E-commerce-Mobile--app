package com.techdev.e_commercemobileapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.AlphaAnimation;
import android.widget.ImageView;

import com.techdev.e_commercemobileapplication.Login.LoginActivity;
import com.techdev.e_commercemobileapplication.SellerHome.ShopperDashboardActivity;
import com.techdev.e_commercemobileapplication.UserHome.UserDashboardActivity;
import com.techdev.e_commercemobileapplication.Utils.SharedPreferencesData;

public class MainActivity extends AppCompatActivity {

    ImageView imageView;

    SharedPreferences sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();

        sp = getSharedPreferences(SharedPreferencesData.PREF, MODE_PRIVATE);

        imageView = findViewById(R.id.main_imageview);
        AlphaAnimation animation = new AlphaAnimation(10, 20);
        animation.setRepeatCount(3);
        animation.setDuration(800);
        imageView.setAnimation(animation);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if(sp.getString(SharedPreferencesData.ID,"").equalsIgnoreCase("")) {
                    new CommonMethod(MainActivity.this, LoginActivity.class);
                    finish();
                }
                else{
                    if(sp.getString(SharedPreferencesData.TYPEOFACCOUNT, "").equalsIgnoreCase("Customer")){
                        new CommonMethod(MainActivity.this, UserDashboardActivity.class);
                        finish();
                    } else {
                        //if(sp.getString(SharedPreferencesData.TYPEOFACCOUNT, "").equalsIgnoreCase("Shopper")) {
                        new CommonMethod(MainActivity.this, ShopperDashboardActivity.class);
                        finish();
                    }
                }
            }
        }, 1000);

//        new Handler().postDelayed(new Runnable() {
//            @Override
//            public void run() {
//                new CommonMethod(MainActivity.this, UserDashboardActivity.class);
//            }
//        }, 500);
    }
}