package com.techdev.e_commercemobileapplication.SellerHome;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.android.material.tabs.TabLayout;
import com.techdev.e_commercemobileapplication.CommonMethod;
import com.techdev.e_commercemobileapplication.Login.LoginActivity;
import com.techdev.e_commercemobileapplication.R;
import com.techdev.e_commercemobileapplication.UserHome.HomeFragment;
import com.techdev.e_commercemobileapplication.UserHome.PlacedOrderFragment;
import com.techdev.e_commercemobileapplication.UserHome.ShoppingCartFragment;
import com.techdev.e_commercemobileapplication.Utils.ApiClient;
import com.techdev.e_commercemobileapplication.Utils.ApiInterface;
import com.techdev.e_commercemobileapplication.Utils.SharedPreferencesData;

public class ShopperDashboardActivity extends AppCompatActivity {

    TabLayout tabLayout;
    ViewPager viewPager;

    Button logout, home, profile;

    SharedPreferences sp;
    ApiInterface apiInterface;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shopper_dashboard);
        getSupportActionBar().hide();

        sp = getSharedPreferences(SharedPreferencesData.PREF, MODE_PRIVATE);
        apiInterface = ApiClient.getClient().create(ApiInterface.class);

        tabLayout = findViewById(R.id.shopper_dashboard_tablayout);
        viewPager = findViewById(R.id.shopper_dashboard_viewPager);

        tabLayout.post(new Runnable() {
            @Override
            public void run() {
                tabLayout.setupWithViewPager(viewPager);
            }
        });

        logout = findViewById(R.id.shopper_dashboard_logoutButton);
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sp.edit().clear().commit();
                new CommonMethod(ShopperDashboardActivity.this, LoginActivity.class);
            }
        });

        home = findViewById(R.id.shopper_dashboard_homeButton);
        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               // new CommonMethod(ShopperDashboardActivity.this, );
            }
        });

        profile = findViewById(R.id.shopper_dashboard_profileButton);
        profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new CommonMethod(ShopperDashboardActivity.this, ShopperProfileViewActivity.class);
            }
        });


        viewPager.setAdapter(new DashboardTabActivityAdapter(getSupportFragmentManager()));

    }

    private class DashboardTabActivityAdapter extends FragmentPagerAdapter {

        public DashboardTabActivityAdapter(FragmentManager supportFragmentManager) {
            super(supportFragmentManager);
        }

        @Nullable
        @Override
        public CharSequence getPageTitle(int position) {

            switch (position){
                case 0 :
                    return "Selling Items";
                case 1 :
                    return "Add Item";
                case 2 :
                    return "Order Request";

            }

            return super.getPageTitle(position);
        }

        @NonNull
        @Override
        public Fragment getItem(int position) {
            switch (position){
                case 0 :
                    return new SellingItemsFragment();
                case 1 :
                    return new AddItemFragment();
                case 2 :
                    return new OrderRequestFragment();
            }
            return null;
        }

        @Override
        public int getCount() {
            return 3;
        }

    }

//    @Override
//    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
//        int id = item.getItemId();
//        if (id == android.R.id.home) {
//            onBackPressed();
//        }
//        return super.onOptionsItemSelected(item);
//    }

}