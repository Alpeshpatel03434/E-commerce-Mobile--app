package com.techdev.e_commercemobileapplication.UserHome;

import static android.content.Context.MODE_PRIVATE;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.techdev.e_commercemobileapplication.CommonMethod;
import com.techdev.e_commercemobileapplication.R;
import com.techdev.e_commercemobileapplication.RetrofitData.DeleteSellerItem;
import com.techdev.e_commercemobileapplication.RetrofitData.UpdateSellerItem;
import com.techdev.e_commercemobileapplication.SellerHome.ItemData;
import com.techdev.e_commercemobileapplication.SellerHome.ItemViewActivity;
import com.techdev.e_commercemobileapplication.Utils.ApiClient;
import com.techdev.e_commercemobileapplication.Utils.ApiInterface;
import com.techdev.e_commercemobileapplication.Utils.ConnectionDetector;
import com.techdev.e_commercemobileapplication.Utils.SharedPreferencesData;

import java.util.ArrayList;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class UserProductRecyclerAdapter extends RecyclerView.Adapter<UserProductRecyclerAdapter.MyHolder>  {

    Context context;
    ArrayList<ProductData> arrayList;
    Bundle bundle;

    ArrayList<ProductData> searchArrayList;
    ApiInterface apiInterface;
    ProgressDialog pd;
    SharedPreferences sp;

    Bitmap bitmapImage;

    public UserProductRecyclerAdapter(Context context, ArrayList<ProductData> arrayList) {
        this.context = context;
        this.arrayList = arrayList;

        searchArrayList = new ArrayList<>();
        searchArrayList.addAll(arrayList);
    }


    @NonNull
    @Override
    public UserProductRecyclerAdapter.MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.custom_user_home_recycler, parent, false);

        return new MyHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull UserProductRecyclerAdapter.MyHolder holder, @SuppressLint("RecyclerView") int position) {

        String img = arrayList.get(position).getProductImage();
        bitmapImage  = getBitmapImage(img);
        holder.ProductImage.setImageBitmap(bitmapImage);
        holder.ProductName.setText(arrayList.get(position).getProductName());
        holder.ProductPrice.setText(arrayList.get(position).getProductPrice());
        holder.ProductDescription.setText(arrayList.get(position).getProductDescription());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                bundle = new Bundle();

                bundle.putString("ProductID", arrayList.get(position).getProductID());
                bundle.putString("ProductImage", arrayList.get(position).getProductImage());
                bundle.putString("ProductName", arrayList.get(position).getProductName());
                bundle.putString("ProductPrice", arrayList.get(position).getProductPrice());
                bundle.putString("ProductDescription", arrayList.get(position).getProductDescription());
                Intent intent = new Intent(holder.itemView.getContext(), UserItemViewActivity.class);
                intent.putExtras(bundle);
                context.startActivity(intent);

            }
        });

        holder.addCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });


        holder.buy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });


    }



    public Bitmap getBitmapImage(String bmp) {
        byte[] decodedString = Base64.decode(bmp, Base64.DEFAULT);
        Bitmap bitmap = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
        return bitmap;
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    protected class MyHolder extends RecyclerView.ViewHolder {

        ImageView ProductImage;
        TextView ProductName, ProductPrice, ProductDescription;
        Button addCart, buy;

        String sProductName, sProductPrice, sProductDescription;

        public MyHolder(@NonNull View itemView) {
            super(itemView);

            apiInterface = ApiClient.getClient().create(ApiInterface.class);
            sp = context.getSharedPreferences(SharedPreferencesData.PREF, MODE_PRIVATE);

            ProductImage = itemView.findViewById(R.id.custom_user_home_recycler_ProductImage);
            ProductName = itemView.findViewById(R.id.custom_user_home_recycler_ProductName);
            ProductPrice = itemView.findViewById(R.id.custom_user_home_recycler_ProductPrice);
            ProductDescription = itemView.findViewById(R.id.custom_user_home_recycler_ProductDescription);

            addCart = itemView.findViewById(R.id.custom_user_home_recycler_AddCartButton);
            buy = itemView.findViewById(R.id.custom_user_home_recycler_BuyButton);


        }
    }

    public void filter(String s) {
        s = s.toLowerCase(Locale.getDefault());
        arrayList.clear();
        if(s.equals("")){
            arrayList.addAll(searchArrayList);
        }
        else{
            for (ProductData list : searchArrayList){
                if(list.getProductName().contains(s) || list.getProductDescription().toLowerCase().contains(s) || list.getProductPrice().toLowerCase().contains(s)){
                    arrayList.add(list);
                }
            }
        }
        notifyDataSetChanged();
    }


}
