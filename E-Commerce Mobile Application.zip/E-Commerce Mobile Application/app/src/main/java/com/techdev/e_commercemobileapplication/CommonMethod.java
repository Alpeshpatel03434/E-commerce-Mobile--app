package com.techdev.e_commercemobileapplication;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.widget.Toast;

import com.google.android.material.snackbar.BaseTransientBottomBar;
import com.google.android.material.snackbar.Snackbar;

import java.util.List;

public class CommonMethod {

    public CommonMethod(Context context, String msg){
        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show();
    }

    public CommonMethod(View view, String msg){
        Snackbar.make(view, msg, BaseTransientBottomBar.LENGTH_LONG).show();
    }

    public CommonMethod(Context context, Class<?> nextClass) {
        Intent intent = new Intent(context, nextClass);
        context.startActivity(intent);
    }


}
