package com.techdev.e_commercemobileapplication.AdminHome;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.techdev.e_commercemobileapplication.CommonMethod;
import com.techdev.e_commercemobileapplication.R;
import com.techdev.e_commercemobileapplication.RetrofitData.DeleteProfile;
import com.techdev.e_commercemobileapplication.RetrofitData.UpdateProfile;
import com.techdev.e_commercemobileapplication.Utils.ApiClient;
import com.techdev.e_commercemobileapplication.Utils.ApiInterface;
import com.techdev.e_commercemobileapplication.Utils.ConnectionDetector;

import java.io.IOException;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AdminviewShopProfileActivity extends AppCompatActivity {

    ImageView sellerProfile;
    TextView FirstLastName, gender, FullAddress;
    EditText Contact, Email;

    Button update, editprofile, delete, back, logout;

    EditText FirstName, LastName, HomeAddress, City, Pincode;
    RadioGroup Gender;

    LinearLayout fANDlName_Linearlayout, fullAddress_Linearlayout;
    private String sUserID, sFirstName, sLastName, sGender, sEmail, sPassword, sContact, sHomeAddress, sCity, sPincode;

    String EmailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

    ApiInterface apiInterface;
    ProgressDialog pd;

    Bundle bundle;

    // Uri indicates, where the image will be picked from
    private Uri filePath;

    // request code
    private final int PICK_IMAGE_REQUEST = 22;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adminview_shop_profile);

        apiInterface = ApiClient.getClient().create(ApiInterface.class);

        sellerProfile = findViewById(R.id.adminview_shop_sellerimage);
        FirstLastName = findViewById(R.id.adminview_shop_firstAndLastname);
        gender = findViewById(R.id.adminview_shop_gender);
        Contact = findViewById(R.id.adminview_shop_contact);
        Email = findViewById(R.id.adminview_shop_email);
        FullAddress = findViewById(R.id.adminview_shop_shopFullAddress);


        Contact.setEnabled(false);
        Email.setEnabled(false);

        fANDlName_Linearlayout = findViewById(R.id.adminview_shop_firstAndLastname_editable);
        FirstName = findViewById(R.id.adminview_shop_firstName);
        LastName = findViewById(R.id.adminview_shop_lastName);

        Gender = findViewById(R.id.adminview_shop_radioGroup_gender);

        fullAddress_Linearlayout = findViewById(R.id.adminview_shop_homeAddressANDcityANDpincode_editable);
        HomeAddress = findViewById(R.id.adminview_shop_homeAddress);
        City = findViewById(R.id.adminview_shop_city);
        Pincode = findViewById(R.id.adminview_shop_pincode);

        editprofile = findViewById(R.id.adminview_shop_EditButton);
        update = findViewById(R.id.adminview_shop_UpdateButton);
        delete = findViewById(R.id.adminview_shop_DeleteButton);

        editprofile.setVisibility(View.VISIBLE);
        update.setVisibility(View.GONE);
        fANDlName_Linearlayout.setVisibility(View.GONE);
        Gender.setVisibility(View.GONE);
        fullAddress_Linearlayout.setVisibility(View.GONE);


        bundle = getIntent().getExtras();

        FirstLastName.setText(bundle.getString("FirstANDLastName"));
        gender.setText(bundle.getString("Gender"));
        Contact.setText(bundle.getString("Contact"));
        Email.setText(bundle.getString("Email"));
        FullAddress.setText(bundle.getString("FullShopAddress"));

        sellerProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SelectImage();
            }
        });

        Gender.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                RadioButton radioButton = findViewById(i);
                sGender = radioButton.getText().toString();
            }
        });

        back = findViewById(R.id.adminview_user_BackButton);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });


        editprofile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirstLastName.setVisibility(View.GONE);
                gender.setVisibility(View.GONE);
                FullAddress.setVisibility(View.GONE);

                Contact.setEnabled(true);
                Email.setEnabled(true);

                editprofile.setVisibility(View.GONE);
                update.setVisibility(View.VISIBLE);
                fANDlName_Linearlayout.setVisibility(View.VISIBLE);
                Gender.setVisibility(View.VISIBLE);
                fullAddress_Linearlayout.setVisibility(View.VISIBLE);
            }
        });

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                sUserID = bundle.getString("UserID");
                sPassword = bundle.getString("Password");

                sFirstName = FirstName.getText().toString();
                sLastName = LastName.getText().toString();
                sContact = Contact.getText().toString();
                sEmail = Email.getText().toString();
                sHomeAddress = HomeAddress.getText().toString();
                sCity = City.getText().toString();
                sPincode = Pincode.getText().toString();

                if (sFirstName.isEmpty() || sFirstName.equals("")){
                    FirstName.setError("FirstName is required");
                } else if (sLastName.isEmpty() || sLastName.equals("")){
                    LastName.setError("LastName is required");
                } else if (Gender.getCheckedRadioButtonId() == -1) {
                    new CommonMethod(AdminviewShopProfileActivity.this, "Please Select Gender");
                } else if (sEmail.isEmpty() || sEmail.equals("")){
                    Email.setError("Email is required");
                } else if (!sEmail.matches(EmailPattern)){
                    Email.setError("Please Enter valid Email");
                }  else if (sContact.isEmpty() || sContact.equals("")){
                    Contact.setError("Contact number is required");
                } else if (sContact.length()<10 && sContact.length()>10){
                    Contact.setError("Please Enter valid Mobile number");
                } else if (sHomeAddress.isEmpty() || sHomeAddress.equals("")){
                    HomeAddress.setError("Home Address is required");
                } else if (sCity.isEmpty() || sCity.equals("-")){
                    City.setError("City is required");
                } else if (sPincode.isEmpty() || sPincode.equals("")){
                    Pincode.setError("Pincode is required");
                } else if (sPincode.length()<6 && sPincode.length()>6){
                    Pincode.setError("Please Enter valid Pincode");
                }
                else {
                    if(new ConnectionDetector(AdminviewShopProfileActivity.this).isConnectingToInternet()){
                        //new CommonMethod(JsonSignupActivity.this,"Internet/Wifi Connected");
                        //new DoSignUp().execute();

                        pd = new ProgressDialog(AdminviewShopProfileActivity.this);
                        pd.setMessage("Please Wait...");
                        pd.setCancelable(false);
                        pd.show();

                        retrofitUpdateData(sUserID, sFirstName, sLastName, sGender, sContact, sEmail, sPassword, sHomeAddress, sCity, sPincode);

                        Contact.setEnabled(false);
                        Email.setEnabled(false);

                        editprofile.setVisibility(View.VISIBLE);
                        update.setVisibility(View.GONE);
                        fANDlName_Linearlayout.setVisibility(View.GONE);
                        Gender.setVisibility(View.GONE);
                        fullAddress_Linearlayout.setVisibility(View.GONE);

                    }
                    else{
                        new ConnectionDetector(AdminviewShopProfileActivity.this).connectiondetect();
                    }
                }

            }
        });

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String userID = sUserID;//arrayList.get(position).getID();
                pd = new ProgressDialog(AdminviewShopProfileActivity.this);
                pd.setMessage("Please Wait...");
                pd.setCancelable(false);
                pd.show();
                retrofitDeleteProfile(userID);

            }
        });


        logout  = findViewById(R.id.adminview_shop_logoutButton);
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });



    }


    private void retrofitUpdateData(String sUserID, String sFirstName, String sLastName, String sGender, String  sContact, String sEmail, String sPassword, String sHomeAddress, String sCity, String sPincode) {

        Call<UpdateProfile> call = apiInterface.updateProfile(
                sUserID, sFirstName, sLastName, sGender, sContact, sEmail, sPassword, sHomeAddress, sCity, sPincode
        );

        call.enqueue(new Callback<UpdateProfile>() {
            @Override
            public void onResponse(Call<UpdateProfile> call, Response<UpdateProfile> response) {
                pd.dismiss();
                if(response.code()==200){

                    if (response.body().status==true){

                        FirstLastName.setText(sFirstName+" "+sLastName);
                        gender.setText(sGender);
                        Contact.setText(sContact);
                        Email.setText(sEmail);
                        FullAddress.setText(sHomeAddress+" "+sCity+" "+sPincode);

                        new CommonMethod(AdminviewShopProfileActivity.this, "Updated SuccessFully");


                    } else {
                        new CommonMethod(AdminviewShopProfileActivity.this, response.body().message);
                    }

                } else {
                    new CommonMethod(AdminviewShopProfileActivity.this,"Server Error Code : "+response.code());
                }

            }

            @Override
            public void onFailure(Call<UpdateProfile> call, Throwable t) {
                pd.dismiss();
                new CommonMethod(AdminviewShopProfileActivity.this, t.getMessage());
            }
        });



    }

    private void retrofitDeleteProfile(String userID) {

        retrofit2.Call<DeleteProfile> call = apiInterface.deleteProfile(userID);

        call.enqueue(new Callback<DeleteProfile>() {
            @Override
            public void onResponse(Call<DeleteProfile> call, Response<DeleteProfile> response) {
                pd.dismiss();
                if(response.code()==200){

                    if (response.body().status==true){

                        new CommonMethod(AdminviewShopProfileActivity.this, "Delete SuccessFull");
                        onBackPressed();

                    } else {
                        new CommonMethod(AdminviewShopProfileActivity.this, response.body().message);
                    }

                } else {
                    new CommonMethod(AdminviewShopProfileActivity.this,"Server Error Code : "+response.code());
                }

            }

            @Override
            public void onFailure(Call<DeleteProfile> call, Throwable t) {
                pd.dismiss();
                new CommonMethod(AdminviewShopProfileActivity.this, t.getMessage());
            }
        });

    }

    // Select Image method
    private void SelectImage()
    {

        // Defining Implicit Intent to mobile gallery
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(
                Intent.createChooser(
                        intent,
                        "Select Image from here..."),
                PICK_IMAGE_REQUEST);
    }

    // Override onActivityResult method
    @Override
    protected void onActivityResult(int requestCode,
                                    int resultCode,
                                    Intent data)
    {

        super.onActivityResult(requestCode,
                resultCode,
                data);

        // checking request code and result code
        // if request code is PICK_IMAGE_REQUEST and
        // resultCode is RESULT_OK
        // then set image in the image view
        if (requestCode == PICK_IMAGE_REQUEST
                && resultCode == RESULT_OK
                && data != null
                && data.getData() != null) {

            // Get the Uri of data
            filePath = data.getData();
            try {

                // Setting image on image view using Bitmap
                Bitmap bitmap = MediaStore
                        .Images
                        .Media
                        .getBitmap(
                                getContentResolver(),
                                filePath);
                sellerProfile.setImageBitmap(bitmap);
            }

            catch (IOException e) {
                // Log the exception
                e.printStackTrace();
            }
        }
    }


}