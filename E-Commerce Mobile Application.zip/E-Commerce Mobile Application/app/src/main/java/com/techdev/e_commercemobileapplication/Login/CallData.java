package com.techdev.e_commercemobileapplication.Login;

public class CallData {

    String UserID, FirstName, LastName, Gender, Email, Contact, Type_Of_Account, HomeAddress, Pincode, City;

    public CallData(String UserID, String firstName, String lastName, String gender, String email, String contact, String type_Of_Account, String homeAddress, String city, String pincode) {
        this.UserID = UserID;
        FirstName = firstName;
        LastName = lastName;
        Gender = gender;
        Email = email;
        Contact = contact;
        Type_Of_Account = type_Of_Account;
        HomeAddress = homeAddress;
        City = city;
        Pincode = pincode;
    }

    public String getUserID() {
        return UserID;
    }

    public void setUserID(String userID) {
        UserID = userID;
    }

    public String getFirstName() {
        return FirstName;
    }

    public void setFirstName(String firstName) {
        FirstName = firstName;
    }

    public String getLastName() {
        return LastName;
    }

    public void setLastName(String lastName) {
        LastName = lastName;
    }

    public String getGender() {
        return Gender;
    }

    public void setGender(String gender) {
        Gender = gender;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getContact() {
        return Contact;
    }

    public void setContact(String contact) {
        Contact = contact;
    }

    public String getType_Of_Account() {
        return Type_Of_Account;
    }

    public void setType_Of_Account(String type_Of_Account) {
        Type_Of_Account = type_Of_Account;
    }

    public String getHomeAddress() {
        return HomeAddress;
    }

    public void setHomeAddress(String homeAddress) {
        HomeAddress = homeAddress;
    }

    public String getPincode() {
        return Pincode;
    }

    public void setPincode(String pincode) {
        Pincode = pincode;
    }

    public String getCity() {
        return City;
    }

    public void setCity(String city) {
        City = city;
    }
}
