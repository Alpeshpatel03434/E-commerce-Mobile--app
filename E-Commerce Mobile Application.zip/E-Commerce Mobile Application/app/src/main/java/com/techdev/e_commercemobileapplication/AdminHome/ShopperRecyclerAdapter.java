package com.techdev.e_commercemobileapplication.AdminHome;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.techdev.e_commercemobileapplication.CommonMethod;
import com.techdev.e_commercemobileapplication.R;
import com.techdev.e_commercemobileapplication.RetrofitData.DeleteProfile;
import com.techdev.e_commercemobileapplication.RetrofitData.UpdateProfile;
import com.techdev.e_commercemobileapplication.Utils.ApiClient;
import com.techdev.e_commercemobileapplication.Utils.ApiInterface;
import com.techdev.e_commercemobileapplication.Utils.ConnectionDetector;

import java.util.ArrayList;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ShopperRecyclerAdapter extends RecyclerView.Adapter<ShopperRecyclerAdapter.MyHolder> {

    Context context;
    ArrayList<SellerData> arrayList;
    Bundle bundle;

    ArrayList<SellerData> searchArrayList;
    ApiInterface apiInterface;
    ProgressDialog pd;

    public ShopperRecyclerAdapter(Context context, ArrayList<SellerData> arrayList) {
        this.context = context;
        this.arrayList = arrayList;

        searchArrayList = new ArrayList<>();
        searchArrayList.addAll(arrayList);
    }

    @NonNull
    @Override
    public MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.custom_shopper_recycler, parent, false);

        return new MyHolder(view);
    }

    public class MyHolder extends RecyclerView.ViewHolder {

        ImageView shop_imageView;
        TextView firstANDlastName, gender, fullAddress;
        EditText contact, email;

        EditText FirstName, LastName, HomeAdress, City, Pincode;
        RadioGroup Gender;
        String sGender;
        LinearLayout fANDlName_Linearlayout, fullAddress_Linearlayout;

        Button update, delete, editable;

        private String sUserID, sFirstName, sLastName, sEmail, sPassword, sContact, sHomeAddress, sCity, sPincode;

        String EmailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

        public MyHolder(@NonNull View itemView) {
            super(itemView);

            apiInterface = ApiClient.getClient().create(ApiInterface.class);

            shop_imageView = itemView.findViewById(R.id.custom_shopper_recycler_shopImage);
            firstANDlastName = itemView.findViewById(R.id.custom_shopper_recycler_firstAndLastname);
            gender = itemView.findViewById(R.id.custom_shopper_recycler_gender);
            contact = itemView.findViewById(R.id.custom_shopper_recycler_mobile);
            email = itemView.findViewById(R.id.custom_shopper_recycler_email);
            fullAddress = itemView.findViewById(R.id.custom_shopper_recycler_shopAddressANDcityANDpincode);

            contact.setEnabled(false);
            email.setEnabled(false);

            fANDlName_Linearlayout = itemView.findViewById(R.id.custom_shopper_recycler_firstAndLastname_editable);
            FirstName = itemView.findViewById(R.id.custom_shopper_recycler_firstName);
            LastName = itemView.findViewById(R.id.custom_shopper_recycler_lastName);

            Gender = itemView.findViewById(R.id.custom_shopper_recycler_radioGroup_gender);

            fullAddress_Linearlayout = itemView.findViewById(R.id.custom_shopper_recycler_homeAddressANDcityANDpincode_editable);
            HomeAdress = itemView.findViewById(R.id.custom_shopper_recycler_homeAddress);
            City = itemView.findViewById(R.id.custom_shopper_recycler_city);
            Pincode = itemView.findViewById(R.id.custom_shopper_recycler_pincode);

            editable = itemView.findViewById(R.id.custom_shopper_recycler_EditProfileButton);
            update = itemView.findViewById(R.id.custom_shopper_recycler_UpdateButton);
            delete = itemView.findViewById(R.id.custom_shopper_recycler_DeleteButton);

            editable.setVisibility(View.VISIBLE);
            update.setVisibility(View.GONE);
            fANDlName_Linearlayout.setVisibility(View.GONE);
            Gender.setVisibility(View.GONE);
            fullAddress_Linearlayout.setVisibility(View.GONE);

        }
    }

    @Override
    public void onBindViewHolder(@NonNull ShopperRecyclerAdapter.MyHolder holder, @SuppressLint("RecyclerView") int position) {

      //  holder.shop_imageView.setImageBitmap();
        holder.firstANDlastName.setText(arrayList.get(position).getFirstName()+" "+arrayList.get(position).getLastName());
        holder.gender.setText(arrayList.get(position).getGender());
        holder.contact.setText(arrayList.get(position).getContact());
        holder.email.setText(arrayList.get(position).getEmail());
        holder.fullAddress.setText(arrayList.get(position).getShopAddress()+", "+arrayList.get(position).getCity()+", Pincode : "+arrayList.get(position).getPincode());


        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                bundle = new Bundle();

                bundle.putString("UserID", arrayList.get(position).getID());
                bundle.putString("Password", arrayList.get(position).getPassword());

                bundle.putString("FirstANDLastName", arrayList.get(position).getFirstName()+" "+arrayList.get(position).getLastName());
                bundle.putString("Gender", arrayList.get(position).getGender()+"");
                bundle.putString("Contact", arrayList.get(position).getContact()+"");
                bundle.putString("Email", arrayList.get(position).getEmail());
                bundle.putString("FullShopAddress", arrayList.get(position).getShopAddress()+", "+arrayList.get(position).getCity()+", Pincode : "+arrayList.get(position).getPincode());
                Intent intent = new Intent(holder.itemView.getContext(), AdminviewUserProfileActivity.class);
                intent.putExtras(bundle);
                context.startActivity(intent);
            }
        });

        holder.editable.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                holder.firstANDlastName.setVisibility(View.GONE);
                holder.gender.setVisibility(View.GONE);
                holder.fullAddress.setVisibility(View.GONE);

                holder.contact.setEnabled(true);
                holder.email.setEnabled(true);

                holder.editable.setVisibility(View.GONE);
                holder.update.setVisibility(View.VISIBLE);
                holder.fANDlName_Linearlayout.setVisibility(View.VISIBLE);
                holder.Gender.setVisibility(View.VISIBLE);
                holder.fullAddress_Linearlayout.setVisibility(View.VISIBLE);

            }
        });


        holder.Gender.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                RadioButton radioButton = holder.itemView.findViewById(i);
                holder.sGender = radioButton.getText().toString();
            }
        });

        holder.update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                holder.sUserID = arrayList.get(position).getID();

                holder.sFirstName = holder.FirstName.getText().toString();
                holder.sLastName = holder.LastName.getText().toString();
                holder.sContact = holder.contact.getText().toString();
                holder.sEmail = holder.email.getText().toString();
                holder.sHomeAddress = holder.HomeAdress.getText().toString();
                holder.sCity = holder.City.getText().toString();
                holder.sPincode = holder.Pincode.getText().toString();

                holder.sPassword = arrayList.get(position).getPassword();

                if (holder.sFirstName.isEmpty() || holder.sFirstName.equals("")){
                    holder.FirstName.setError("FirstName is required");
                } else if (holder.sLastName.isEmpty() || holder.sLastName.equals("")){
                    holder.LastName.setError("LastName is required");
                } else if (holder.Gender.getCheckedRadioButtonId() == -1) {
                    new CommonMethod(context.getApplicationContext(), "Please Select Gender");
                } else if (holder.sEmail.isEmpty() || holder.sEmail.equals("")){
                    holder.email.setError("Email is required");
                } else if (!holder.sEmail.matches(holder.EmailPattern)){
                    holder.email.setError("Please Enter valid Email");
                }  else if (holder.sContact.isEmpty() || holder.sContact.equals("")){
                    holder.contact.setError("Contact number is required");
                } else if (holder.sContact.length()<10 && holder.sContact.length()>10){
                    holder.contact.setError("Please Enter valid Mobile number");
                } else if (holder.sHomeAddress.isEmpty() || holder.sHomeAddress.equals("")){
                    holder.HomeAdress.setError("Home Address is required");
                } else if (holder.sCity.isEmpty() || holder.sCity.equals("-")){
                    holder.City.setError("City is required");
                } else if (holder.sPincode.isEmpty() || holder.sPincode.equals("")){
                    holder.Pincode.setError("Pincode is required");
                } else if (holder.sPincode.length()<6 && holder.sPincode.length()>6){
                    holder.Pincode.setError("Please Enter valid Pincode");
                }
                else {
                    if(new ConnectionDetector(context.getApplicationContext()).isConnectingToInternet()){
                        //new CommonMethod(JsonSignupActivity.this,"Internet/Wifi Connected");
                        //new DoSignUp().execute();

                        pd = new ProgressDialog(view.getContext());
                        pd.setMessage("Please Wait...");
                        pd.setCancelable(false);
                        pd.show();

                        retrofitUpdateData(holder.itemView.getContext(), holder.sUserID, holder.sFirstName, holder.sLastName, holder.sGender, holder.sContact, holder.sEmail, holder.sPassword, holder.sHomeAddress, holder.sCity, holder.sPincode);

                        holder.contact.setEnabled(false);
                        holder.email.setEnabled(false);

                        holder.editable.setVisibility(View.VISIBLE);
                        holder.update.setVisibility(View.GONE);
                        holder.fANDlName_Linearlayout.setVisibility(View.GONE);
                        holder.Gender.setVisibility(View.GONE);
                        holder.fullAddress_Linearlayout.setVisibility(View.GONE);


                    }
                    else{
                        new ConnectionDetector(context.getApplicationContext()).connectiondetect();
                    }
                }

            }
        });

        holder.delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String userID = arrayList.get(position).getID();
                pd = new ProgressDialog(holder.itemView.getContext());
                pd.setMessage("Please Wait...");
                pd.setCancelable(false);
                pd.show();
                retrofitDeleteProfile(holder.itemView.getContext(), userID);
            }
        });

    }

    private void retrofitUpdateData(Context context, String sUserID, String sFirstName, String sLastName, String sGender, String  sContact, String sEmail, String sPassword, String sHomeAddress, String sCity, String sPincode) {

        Call<UpdateProfile> call = apiInterface.updateProfile(
                sUserID, sFirstName, sLastName, sGender, sContact, sEmail, sPassword, sHomeAddress, sCity, sPincode
        );

        call.enqueue(new Callback<UpdateProfile>() {
            @Override
            public void onResponse(Call<UpdateProfile> call, Response<UpdateProfile> response) {
                pd.dismiss();
                if(response.code()==200){

                    if (response.body().status==true){

                        SellerData list = new SellerData();
                        list.setID(sUserID);
                        list.setFirstName(sFirstName);
                        list.setLastName(sLastName);
                        list.setGender(sGender);
                        list.setContact(sContact);
                        list.setEmail(sEmail);
                        list.setPassword(sPassword);
                        list.setShopAddress(sHomeAddress);
                        list.setCity(sCity);
                        list.setPincode(sPincode);


                        arrayList.set(arrayList.indexOf(sUserID), list);
                        searchArrayList.set(arrayList.indexOf(sUserID), list);
                        searchArrayList.addAll(arrayList);
                        new CommonMethod(context, response.body().message);

                    } else {
                        new CommonMethod(context, response.body().message);
                    }

                } else {
                    new CommonMethod(context,"Server Error Code : "+response.code());
                }

            }

            @Override
            public void onFailure(Call<UpdateProfile> call, Throwable t) {
                pd.dismiss();
                new CommonMethod(context, t.getMessage());
            }
        });



    }

    private void retrofitDeleteProfile(Context context, String userID) {

        retrofit2.Call<DeleteProfile> call = apiInterface.deleteProfile(userID);

        call.enqueue(new Callback<DeleteProfile>() {
            @Override
            public void onResponse(Call<DeleteProfile> call, Response<DeleteProfile> response) {
                pd.dismiss();
                if(response.code()==200){

                    if (response.body().status==true){

                        arrayList.remove(userID);
                       // searchArrayList.addAll(arrayList);
                        new CommonMethod(context, response.body().message);


                    } else {
                        new CommonMethod(context, response.body().message);
                    }

                } else {
                    new CommonMethod(context,"Server Error Code : "+response.code());
                }

            }

            @Override
            public void onFailure(Call<DeleteProfile> call, Throwable t) {
                pd.dismiss();
                new CommonMethod(context, t.getMessage());
            }
        });

    }

    public void filter(String s) {
        s = s.toLowerCase(Locale.getDefault());
        arrayList.clear();
        if(s.equals("")){
            arrayList.addAll(searchArrayList);
        }
        else{
            for (SellerData list : searchArrayList){
                if(list.getEmail().contains(s) || list.getFirstName().toLowerCase().contains(s) || list.getLastName().toLowerCase().contains(s) || list.getGender().contains(s) || list.getContact().contains(s) || list.getCity().contains(s) || list.getPincode().contains(s)){
                    arrayList.add(list);
                }
            }
        }
        notifyDataSetChanged();
    }


    @Override
    public int getItemCount() {
        return arrayList.size();
    }

}
