package com.techdev.e_commercemobileapplication.SignUp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import com.techdev.e_commercemobileapplication.CommonMethod;
import com.techdev.e_commercemobileapplication.Login.LoginActivity;
import com.techdev.e_commercemobileapplication.MainActivity;
import com.techdev.e_commercemobileapplication.R;
import com.techdev.e_commercemobileapplication.RetrofitData.SignupData;
import com.techdev.e_commercemobileapplication.Utils.API_URL;
import com.techdev.e_commercemobileapplication.Utils.ApiClient;
import com.techdev.e_commercemobileapplication.Utils.ApiInterface;
import com.techdev.e_commercemobileapplication.Utils.ConnectionDetector;
import com.techdev.e_commercemobileapplication.Utils.MakeServiceCall;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.Executor;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class SignUpActivity extends AppCompatActivity {

    EditText firstname, lastname, contact, email, password, homeAddress, pincode;
    Spinner city;
    RadioGroup gender, typeOFaccount;

    Button submit, login;

    ArrayList<String> arrayList;
    String EmailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
    private String FirstName, LastName, Gender, Email, Password, Contact, TypeOFAccount, HomeAddress, City, Pincode;

    ApiInterface apiInterface;
    ProgressDialog pd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        getSupportActionBar().setTitle("Signup");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        apiInterface = ApiClient.getClient().create(ApiInterface.class);


        firstname = findViewById(R.id.signup_fname_input);
        lastname = findViewById(R.id.signup_lname_input);
        email = findViewById(R.id.signup_email_input);
        password = findViewById(R.id.signup_passwd_input);
        contact = findViewById(R.id.signup_mobile_input);
        homeAddress = findViewById(R.id.signup_homeaddress_input);
        pincode = findViewById(R.id.signup_pincode_input);


        gender = findViewById(R.id.signup_radioGroup_gender);
        gender.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                RadioButton radioButton = findViewById(i);
                Gender = radioButton.getText().toString();
                new CommonMethod(SignUpActivity.this, Gender);
            }
        });

        typeOFaccount = findViewById(R.id.signup_radioGroup_typeOfaccount);
        typeOFaccount.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                RadioButton radioButton = findViewById(i);
                TypeOFAccount = radioButton.getText().toString();
                new CommonMethod(SignUpActivity.this, TypeOFAccount);
            }
        });

//        if(TypeOFAccount.equalsIgnoreCase("Seller")){
//            homeAddress.setHint("Seller Address");
//        }

        arrayList = new ArrayList<>();
        arrayList.add("-");
        arrayList.add("Ahmedabad");
        arrayList.add("Vadodara");
        arrayList.add("Surat");
        arrayList.add("Navsari");
        arrayList.add("Valsad");
        arrayList.add("Vapi");
        arrayList.add("Bharuch");
        arrayList.add("Rajkot");
        arrayList.add("Nadiad");
        arrayList.add("Mumbai");
        arrayList.add("Delhi");
        arrayList.add("Bangalore");
        arrayList.add("Hyderabad");
        arrayList.add("Pune");
        arrayList.add("Chennai");
        arrayList.add("Kolkata");
        city = findViewById(R.id.signup_city_Spinner);
        ArrayAdapter adapter = new ArrayAdapter(SignUpActivity.this, android.R.layout.simple_list_item_1, arrayList);
        adapter.setDropDownViewResource(android.R.layout.simple_list_item_checked);
        city.setAdapter(adapter);
        city.setSelection(arrayList.indexOf("-"));
        city.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                City = arrayList.get(position);
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        submit = findViewById(R.id.signup_submitButton);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirstName = firstname.getText().toString();
                LastName = lastname.getText().toString();
                Contact = contact.getText().toString();
                Email = email.getText().toString();
                Password = password.getText().toString();
                HomeAddress = homeAddress.getText().toString();
                Pincode = pincode.getText().toString();


                if (FirstName.isEmpty() || FirstName.equals("")){
                    firstname.setError("FirstName is required");
                } else if (LastName.isEmpty() || LastName.equals("")){
                    lastname.setError("LastName is required");
                } else if (gender.getCheckedRadioButtonId() == -1) {
                    new CommonMethod(SignUpActivity.this, "Please Select Gender");
                } else if (Email.isEmpty() || Email.equals("")){
                    email.setError("Email is required");
                } else if (!Email.matches(EmailPattern)){
                    email.setError("Please Enter valid Email");
                }  else if (Password.isEmpty() || Password.equals("")){
                    password.setError("Password is required");
                } else if (Password.length()<8){
                    password.setError("Password must be 8 char long");
                } else if (Contact.isEmpty() || Contact.equals("")){
                    contact.setError("Contact number is required");
                } else if (Contact.length()<10 && Contact.length()>10){
                    contact.setError("Please Enter valid Mobile number");
                } else if (HomeAddress.isEmpty() || HomeAddress.equals("")){
                    homeAddress.setError("Home Address is required");
                } else if (City.isEmpty() || City.equals("-")){
                    new CommonMethod(SignUpActivity.this, "Please Select City");
                } else if (Pincode.isEmpty() || Pincode.equals("")){
                    pincode.setError("Pincode is required");
                } else if (Pincode.length()<6 && Pincode.length()>6){
                    pincode.setError("Please Enter valid Pincode");
                }
                else {
                    if(new ConnectionDetector(SignUpActivity.this).isConnectingToInternet()){
                        //new CommonMethod(JsonSignupActivity.this,"Internet/Wifi Connected");
                        //new DoSignUp().execute();

                        pd = new ProgressDialog(SignUpActivity.this);
                        pd.setMessage("Please Wait...");
                        pd.setCancelable(false);
                        pd.show();
                        retrofitSignupData(FirstName, LastName, Gender, Contact, Email, Password, TypeOFAccount, HomeAddress, City, Pincode);

                    }
                    else{
                        new ConnectionDetector(SignUpActivity.this).connectiondetect();
                    }
                }
            }
        });

        login = findViewById(R.id.signup_loginButton);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new CommonMethod(SignUpActivity.this, LoginActivity.class);
            }
        });


    }

    private void retrofitSignupData(String FirstName, String LastName, String Gender, String Contact, String Email, String Password, String TypeOFAccount, String HomeAddress, String City, String Pincode) {

        Call<SignupData> call = apiInterface.signupData(
                FirstName, LastName, Gender, Contact, Email, Password, TypeOFAccount, HomeAddress, City, Pincode);

        call.enqueue(new Callback<SignupData>() {
            @Override
            public void onResponse(Call<SignupData> call, Response<SignupData> response) {
                pd.dismiss();
                if(response.code()==200){
                    if(response.body().status==true){
                        new CommonMethod(SignUpActivity.this, response.body().message);
                        onBackPressed();
                    }
                    else{
                        new CommonMethod(SignUpActivity.this, response.body().message);
                    }
                }
                else{
                    new CommonMethod(SignUpActivity.this,"Server Error Code : "+response.code());
                }
            }

            @Override
            public void onFailure(Call<SignupData> call, Throwable t) {
                pd.dismiss();
                new CommonMethod(SignUpActivity.this,t.getMessage());
            }
        });
    }


    private class DoSignUp extends AsyncTask<String, String, String> {

        private ProgressDialog progressDialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = new ProgressDialog(SignUpActivity.this);
            progressDialog.setMessage("Please Wait...");
            progressDialog.setCancelable(false);
            progressDialog.show();
        }

        @Override
        protected String doInBackground(String... strings) {
            HashMap<String,String> hashMap = new HashMap<>();

            hashMap.put("firstname", FirstName);
            hashMap.put("lastname", LastName);
            hashMap.put("gender", Gender);
            hashMap.put("contact", Contact);
            hashMap.put("email", Email);
            hashMap.put("password", Password);
            hashMap.put("type_of_account", TypeOFAccount);
            hashMap.put("homeAddress", HomeAddress);
            hashMap.put("city", City);
            hashMap.put("pincode", Pincode);

            return null;
           // return new MakeServiceCall().MakeServiceCall(API_URL.URL+"NewUser.php", MakeServiceCall.POST, hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            progressDialog.dismiss();
            try {
                JSONObject object = new JSONObject(s);
               // if(object.getBoolean("Status")==true){
                    new CommonMethod(SignUpActivity.this, object.getString("Message"));
                    new CommonMethod(SignUpActivity.this, LoginActivity.class);
               // }
              //  else{
                    new CommonMethod(SignUpActivity.this, object.getString("Message"));
              //  }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
}