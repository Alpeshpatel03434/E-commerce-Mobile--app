package com.techdev.e_commercemobileapplication.UserHome;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.android.material.tabs.TabLayout;
import com.techdev.e_commercemobileapplication.CommonMethod;
import com.techdev.e_commercemobileapplication.Login.LoginActivity;
import com.techdev.e_commercemobileapplication.R;
import com.techdev.e_commercemobileapplication.Utils.ApiClient;
import com.techdev.e_commercemobileapplication.Utils.ApiInterface;
import com.techdev.e_commercemobileapplication.Utils.SharedPreferencesData;

public class UserDashboardActivity extends AppCompatActivity {

    TabLayout tabLayout;
    ViewPager viewPager;

    Button logout, home, profile;

    SharedPreferences sp;
    ApiInterface apiInterface;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_dashboard);

        sp = getSharedPreferences(SharedPreferencesData.PREF, MODE_PRIVATE);
        apiInterface = ApiClient.getClient().create(ApiInterface.class);

        tabLayout = findViewById(R.id.user_dashboard_tablayout);
        viewPager = findViewById(R.id.user_dashboard_viewPager);

        tabLayout.post(new Runnable() {
            @Override
            public void run() {
                tabLayout.setupWithViewPager(viewPager);
            }
        });

        logout = findViewById(R.id.user_dashboard_logoutButton);
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sp.edit().clear().commit();
                new CommonMethod(UserDashboardActivity.this, LoginActivity.class);
            }
        });

        home = findViewById(R.id.user_dashboard_homeButton);
        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new CommonMethod(UserDashboardActivity.this, HomeFragment.class);
            }
        });

        profile = findViewById(R.id.user_dashboard_profileButton);
        profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new CommonMethod(UserDashboardActivity.this, UserProfileViewActivity.class);
            }
        });


        viewPager.setAdapter(new DashboardTabActivityAdapter(getSupportFragmentManager()));

    }

    private class DashboardTabActivityAdapter extends FragmentPagerAdapter {

        public DashboardTabActivityAdapter(FragmentManager supportFragmentManager) {
            super(supportFragmentManager);
        }

        @Nullable
        @Override
        public CharSequence getPageTitle(int position) {

            switch (position){
                case 0 :
                    return "Home";
                case 1 :
                    return "Shopping Cart";
                case 2 :
                    return "Placed Order";
                case 3 :
                    return "Order History";

            }

            return super.getPageTitle(position);
        }

        @NonNull
        @Override
        public Fragment getItem(int position) {
            switch (position){
                case 0 :
                    return new HomeFragment();
                case 1 :
                    return new ShoppingCartFragment();
                case 2 :
                    return new PlacedOrderFragment();
                case 3 :
                    return new OrderHistoryFragment();
            }
            return null;
        }

        @Override
        public int getCount() {
            return 4;
        }

    }


}