package com.techdev.e_commercemobileapplication.SellerHome;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.Image;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import com.techdev.e_commercemobileapplication.CommonMethod;
import com.techdev.e_commercemobileapplication.Login.LoginActivity;
import com.techdev.e_commercemobileapplication.R;
import com.techdev.e_commercemobileapplication.RetrofitData.DeleteSellerItem;
import com.techdev.e_commercemobileapplication.RetrofitData.UpdateSellerItem;
import com.techdev.e_commercemobileapplication.UserHome.UserDashboardActivity;
import com.techdev.e_commercemobileapplication.Utils.ApiClient;
import com.techdev.e_commercemobileapplication.Utils.ApiInterface;
import com.techdev.e_commercemobileapplication.Utils.ConnectionDetector;
import com.techdev.e_commercemobileapplication.Utils.SharedPreferencesData;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ItemViewActivity extends AppCompatActivity {

    ImageView productimageView;
    String productImageString;
    Bitmap productBitmapImageview;
    EditText productName, productPrice, productDescription;
    Button editbutton, update, delete, back, logout;

    ApiInterface apiInterface;
    SharedPreferences sp;
    ProgressDialog pd;

    String sProductName, sProductPrice, sProductDescription;

    Bundle bundle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_view);

        sp = getSharedPreferences(SharedPreferencesData.PREF, MODE_PRIVATE);
        apiInterface = ApiClient.getClient().create(ApiInterface.class);

        bundle = getIntent().getExtras();

        productimageView = findViewById(R.id.seller_item_itemimage);
        productName = findViewById(R.id.seller_item_productName);
        productPrice = findViewById(R.id.seller_item_productPrice);
        productDescription = findViewById(R.id.seller_item_productDescription);

        editbutton = findViewById(R.id.seller_item_EditButton);
        update = findViewById(R.id.seller_item_UpdateButton);
        delete = findViewById(R.id.seller_item_DeleteButton);
        back = findViewById(R.id.seller_item_BackButton);
        logout = findViewById(R.id.seller_item_logoutButton);

        update.setVisibility(View.GONE);
        editbutton.setVisibility(View.VISIBLE);
        productName.setEnabled(false);
        productPrice.setEnabled(false);
        productDescription.setEnabled(false);


        productImageString = bundle.getString("ProductImage");
        productBitmapImageview = getBitmapImage(productImageString);
        productimageView.setImageBitmap(productBitmapImageview);
        productName.setText(bundle.getString("ProductName"));
        productPrice.setText(bundle.getString("ProductPrice"));
        productDescription.setText(bundle.getString("ProductDescription"));


        editbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                productName.setEnabled(true);
                productPrice.setEnabled(true);
                productDescription.setEnabled(true);

                editbutton.setVisibility(View.GONE);
                update.setVisibility(View.VISIBLE);
            }
        });

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                sProductName = productName.getText().toString();
                sProductPrice = productPrice.getText().toString();
                sProductDescription = productDescription.getText().toString();

                if(sProductName.isEmpty() || sProductName.equalsIgnoreCase("")){
                    productName.setError("Product Name is required");
                } else if(sProductPrice.isEmpty() || sProductPrice.equalsIgnoreCase("")){
                    productPrice.setError("Product Price is required");
                } else if(sProductDescription.isEmpty() || sProductDescription.equalsIgnoreCase("")){
                    productDescription.setError("Product Description is required");
                } else {
                    if(new ConnectionDetector(ItemViewActivity.this).isConnectingToInternet()){

                        String pid = bundle.getString("ProductID");
                        String userid = sp.getString(SharedPreferencesData.ID,"");
                        String email = sp.getString(SharedPreferencesData.EMAIL,"");

                        pd = new ProgressDialog(ItemViewActivity.this);
                        pd.setMessage("Please Wait...");
                        pd.setCancelable(false);
                        pd.show();
                        retrofitUpdate(pid, userid, email, productImageString, sProductName, sProductPrice, sProductDescription);
                    }
                    else{
                        new ConnectionDetector(ItemViewActivity.this).connectiondetect();
                    }

                }

            }
        });


        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String record = bundle.getString("ProductID");
                pd = new ProgressDialog(ItemViewActivity.this);
                pd.setMessage("Please Wait...");
                pd.setCancelable(false);
                pd.show();
                retrofitDeleteProfile(record);
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sp.edit().clear().commit();
                new CommonMethod(ItemViewActivity.this, LoginActivity.class);
            }
        });


    }

    private void retrofitDeleteProfile(String record) {

        Call<DeleteSellerItem> call = apiInterface.deleteSellerItem(
                record
        );

        call.enqueue(new Callback<DeleteSellerItem>() {
            @Override
            public void onResponse(Call<DeleteSellerItem> call, Response<DeleteSellerItem> response) {

                pd.dismiss();
                if(response.code()==200){

                    if (response.body().status==true){

                        new CommonMethod(ItemViewActivity.this, "Delete SuccessFull");

                    } else {
                        new CommonMethod(ItemViewActivity.this, response.body().message);
                    }

                } else {
                    new CommonMethod(ItemViewActivity.this,"Server Error Code : "+response.code());
                }

            }

            @Override
            public void onFailure(Call<DeleteSellerItem> call, Throwable t) {
                pd.dismiss();
                new CommonMethod(ItemViewActivity.this, t.getMessage());
            }
        });

    }

    private void retrofitUpdate(String pid, String userid, String email, String image, String name, String price, String desc) {

        Call<UpdateSellerItem> call = apiInterface.updateSellerItem(
                pid, userid, email, image, name, price, desc
        );

        call.enqueue(new Callback<UpdateSellerItem>() {
            @Override
            public void onResponse(Call<UpdateSellerItem> call, Response<UpdateSellerItem> response) {

                pd.dismiss();
                if(response.code()==200){

                    if (response.body().status==true){

                        new CommonMethod(ItemViewActivity.this, "Updated SuccessFully");

                    } else {
                        new CommonMethod(ItemViewActivity.this, response.body().message);
                    }

                } else {
                    new CommonMethod(ItemViewActivity.this,"Server Error Code : "+response.code());
                }

            }

            @Override
            public void onFailure(Call<UpdateSellerItem> call, Throwable t) {
                pd.dismiss();
                new CommonMethod(ItemViewActivity.this, t.getMessage());
            }
        });

    }

    public Bitmap getBitmapImage(String bmp) {
        byte[] decodedString = Base64.decode(bmp, Base64.DEFAULT);
        Bitmap bitmap = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
        return bitmap;
    }

}