package com.techdev.e_commercemobileapplication.Utils;

public class SharedPreferencesData {

    public static final String PREF = "pref";
    public static final String ID = "id";
    public static final String FIRSTNAME = "firstname";
    public static final String LASTNAME = "lastname";
    public static final String GENDER = "gender";
    public static final String CONTACT = "contact";
    public static final String EMAIL = "email";
    public static final String PASSWORD = "password";
    public static final String TYPEOFACCOUNT = "type_of_account";
    public static final String HOMEORSHOPADDRESS = "homeAddress";
    public static final String CITY = "city";
    public static final String PINCODE = "pincode";


}
