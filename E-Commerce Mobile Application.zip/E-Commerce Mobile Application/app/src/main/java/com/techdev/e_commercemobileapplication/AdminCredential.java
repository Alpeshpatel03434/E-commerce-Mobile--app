package com.techdev.e_commercemobileapplication;

import java.util.ArrayList;

public class AdminCredential {

    String AdminEmail;
    String AdminPassword;

    ArrayList<String> adminEmail;
    ArrayList<String> adminPassword;

    public AdminCredential() {
        adminEmail = new ArrayList<>();
        adminPassword = new ArrayList<>();
        getAdminCredential();
    }

    public void getAdminCredential() {

        adminEmail.add("Admin@gmail.com");
        adminEmail.add("Admin123@gmail.com");
        adminEmail.add("Admin12@gmail.com");
        adminEmail.add("Admin1234@gmail.com");

        adminPassword.add("12345678");
        adminPassword.add("Admin123");
        adminPassword.add("Admin012");
        adminPassword.add("Admin1234");

    }

    public Boolean CheckCredential(String Email, String Password){

        int indexOfEmail = adminEmail.indexOf(Email);
        int indexOfPassword = adminPassword.indexOf(Password);

        if(indexOfEmail==-1 || indexOfPassword==-1){
            return false;
        } else {
            return true;
        }

    }

}
