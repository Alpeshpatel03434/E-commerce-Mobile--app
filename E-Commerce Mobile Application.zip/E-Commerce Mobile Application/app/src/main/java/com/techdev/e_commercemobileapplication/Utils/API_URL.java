package com.techdev.e_commercemobileapplication.Utils;

public class API_URL {

    // TODO Local IP Address
    public static final String URL = "http://192.168.43.46/android_demo/";

    //TODO Live URL
    // public static final String URL = "https://fleecy-defeats.000webhostapp.com/";

}
