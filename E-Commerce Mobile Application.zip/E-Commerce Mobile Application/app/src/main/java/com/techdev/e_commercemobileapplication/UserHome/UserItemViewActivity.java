package com.techdev.e_commercemobileapplication.UserHome;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.razorpay.Checkout;
import com.razorpay.PaymentResultListener;
import com.techdev.e_commercemobileapplication.CommonMethod;
import com.techdev.e_commercemobileapplication.Login.LoginActivity;
import com.techdev.e_commercemobileapplication.R;
import com.techdev.e_commercemobileapplication.Utils.ApiClient;
import com.techdev.e_commercemobileapplication.Utils.ApiInterface;
import com.techdev.e_commercemobileapplication.Utils.SharedPreferencesData;

import org.json.JSONObject;

public class UserItemViewActivity extends AppCompatActivity {

    ImageView productimageView;
    String productImageString;
    Bitmap productBitmapImageview;
    EditText productName, productPrice, productDescription;
    Button addCart, buy, back, logout;

    ApiInterface apiInterface;
    SharedPreferences sp;
    ProgressDialog pd;

    String sProductName, sProductPrice, sProductDescription;

    Bundle bundle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_item_view);

        sp = getSharedPreferences(SharedPreferencesData.PREF, MODE_PRIVATE);
        apiInterface = ApiClient.getClient().create(ApiInterface.class);

        bundle = getIntent().getExtras();

        productimageView = findViewById(R.id.user_item_view_itemimage);
        productName = findViewById(R.id.user_item_view_productName);
        productPrice = findViewById(R.id.user_item_view_productPrice);
        productDescription = findViewById(R.id.user_item_view_productDescription);

        addCart = findViewById(R.id.user_item_view_AddCartButton);
        buy = findViewById(R.id.user_item_view_BuyButton);
        back = findViewById(R.id.user_item_view_BackButton);
        logout = findViewById(R.id.user_item_view_logoutButton);

        addCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        buy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new Payment().startPayment();
                addHistory();
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sp.edit().clear().commit();
                new CommonMethod(UserItemViewActivity.this, LoginActivity.class);
            }
        });

    }

    private void addHistory() {



    }

    private class Payment implements PaymentResultListener {

        public void startPayment() {

            Checkout checkout = new Checkout();

            checkout.setImage(R.mipmap.ic_launcher);

            final Activity activity = UserItemViewActivity.this;

            try {
                JSONObject options = new JSONObject();
                options.put("name", R.string.app_name);
                options.put("description", "Payment for Anything");
                options.put("send_sms_hash", true);
                options.put("allow_rotation", false);

                //You can omit the image option to fetch the image from dashboard
                options.put("currency", "INR");
                options.put("amount", sProductPrice);

                JSONObject preFill = new JSONObject();
                preFill.put("email", "");
                preFill.put("contact", "");

                options.put("prefill", preFill);

                checkout.open(activity, options);
            } catch (Exception e) {
                Toast.makeText(activity, "Error in payment: " + e.getMessage(), Toast.LENGTH_SHORT)
                        .show();
                e.printStackTrace();
            }

        }

        @Override
        public void onPaymentSuccess(String s) {
            Toast.makeText(UserItemViewActivity.this, "SuccessFully "+s, Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onPaymentError(int i, String s) {
            Toast.makeText(UserItemViewActivity.this, i+" UnSuccessFully "+s, Toast.LENGTH_SHORT).show();
        }

    }


}